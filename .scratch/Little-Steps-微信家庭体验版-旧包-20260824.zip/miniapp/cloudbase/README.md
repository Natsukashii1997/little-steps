# 家庭体验版云开发配置

本目录提供最小云端配置：家庭成员表、家庭当前快照、滚动备份，以及照片/音频存储规则。应用内最多 5 位家庭成员。

## 数据结构

- `families`：家庭所有者、成员微信身份、6 位邀请码和人数上限。
- `family_snapshots`：家庭业务数据的带版本当前快照。
- `family_backups`：每次成功保存产生的可恢复备份，每个家庭滚动保留最新 30 份。
- 云存储 `family-media/<openid>/...`：照片和音频；数据库只保存 fileID。

所有数据库读写都经 `familyApi` 云函数完成，小程序客户端不能直接访问数据库。快照使用版本号检测并发冲突；离线编辑会在恢复网络后合并，不会用旧手机数据静默覆盖较新的家庭记录。当前快照与对应版本备份在同一个数据库事务内写入，不会出现“显示保存成功但没有该版本备份”的半完成状态。

## 首次配置

1. 用自己的 AppID 导入包含 `project.config.json` 的项目根目录。
2. 创建云开发环境，复制环境 ID 到 `miniprogram/config.local.js`。
3. 新建 `families`、`family_snapshots` 和 `family_backups` 三个集合。
4. 分别把 [database.rules.json](./database.rules.json) 的内容发布到三个集合。顶层 `read:false`、`write:false` 会拒绝客户端直连，云函数不受影响。
5. 把 [storage.rules.json](./storage.rules.json) 发布为云存储安全规则。
6. 右键 `cloudfunctions/familyApi`，选择“上传并部署：云端安装依赖”。

## 权限边界

- 只有加入家庭的微信身份可以通过 `familyApi` 读取和保存该家庭快照。
- 家庭达到 5 人后会拒绝第 6 人。
- 云存储只开放 `family-media/` 前缀；已登录体验成员可读取，文件创建者才能覆盖或删除自己的文件。
- 本版本不提供成员退出或移除。首次只邀请确定长期使用的 5 个账号以内。
- 家庭成员可列出备份和导出家庭数据；只有家庭创建者可以执行恢复。
- 恢复必须携带当前 `expectedVersion`。云函数会校验成员、所有者、备份家庭归属、版本、容量和 SHA-256；并在与恢复相同的事务中额外保存一份 `pre_restore` 备份。

不要在代码、聊天或截图中提供 AppSecret、管理员密码或云环境管理密钥。小程序客户端不需要这些密钥。

## 备份、导出与恢复接口

`familyApi` 新增三个向后兼容的 action。原有 `bootstrap/createFamily/join/load/save/getStatus` 的请求和主要响应字段保持不变。

### `listBackups`

```json
{ "action": "listBackups", "familyId": "...", "limit": 30 }
```

返回最新 1–30 份备份的元数据，不在列表中携带完整家庭数据。每个家庭最多保留 30 份，包含恢复前自动产生的保护备份。

### `restoreBackup`

```json
{
  "action": "restoreBackup",
  "familyId": "...",
  "backupId": "...",
  "expectedVersion": 12
}
```

仅家庭创建者可调用。成功后不会把版本号倒退到旧版本，而是把选中备份内容作为一个新版本写入。这样现有客户端的版本冲突机制仍然有效。

### `exportFamily`

```json
{ "action": "exportFamily", "familyId": "..." }
```

返回 `baby-care-family-export-v1` JSON，包含快照数据、版本、字节数和 SHA-256，不包含邀请码或成员 openid。小程序“家庭同步”页面已经接入导出和文件分享；当前尚未提供文件导入入口，因此它属于环境外离线存档，不应对用户表述为可在小程序内一键恢复的备份。

## 容量状态

`load.snapshot.capacity`、`save.capacity` 和 `exportFamily.capacity` 会返回：

```json
{
  "storageFormat": "legacy-snapshot-v1",
  "snapshotBytes": 20300,
  "snapshotLimitBytes": 850000,
  "usageRatio": 0.0239,
  "warning": false,
  "partitionMigrationAvailable": false
}
```

当快照达到上限的 80% 时 `warning` 变为 `true`。“家庭同步”页面会展示已用容量、百分比和接近上限的警告；在完成下述分区迁移前，仍应定期导出离线存档，并及时处理容量警告。

## 后续分区存储迁移契约

本轮不直接将 `load/save` 切换为分区存储。现有客户端每次上传、下载整个快照；只在服务端拆数据库文档，无法解决云函数请求/响应体的整体上限，还会引入跨文档半提交风险。因此当前保留 850,000 字节限制和完整向后兼容。

后续 v2 必须按以下契约分阶段实施：

1. 新增 `family_manifests`：保存家庭总 revision、schemaVersion，以及各分区的 ID、版本、字节数和 SHA-256。
2. 新增 `family_partitions`：把宝宝资料和当前任务放在小型 `core` 分区；成长、喂养、睡眠、便便、健康、记忆等按业务类型和 `YYYY-MM` 时间桶分区。媒体仍只存 fileID。
3. 先发布兼容客户端：调用 `loadManifest/loadPartition`；如果没有 manifest，继续使用现有 `load`。
4. 只有家庭创建者可触发一次性 `migrateSnapshotV2`。迁移必须携带旧快照 expectedVersion 和 checksum，先备份，再在事务内写入全部分区与 manifest。
5. 新客户端使用 `savePartition`，同时携带家庭总 revision 和分区版本；仅上传变化的分区。
6. 分区备份保存 manifest 和不可变分区版本指针，恢复时仍以新 revision 写入，不倒退版本号。
7. 所有家庭设备升级并通过双机演练前，不删除旧 `load/save`，也不删除最后一份 legacy 快照。

这项迁移需要客户端配合，不能只改云函数就安全完成。
