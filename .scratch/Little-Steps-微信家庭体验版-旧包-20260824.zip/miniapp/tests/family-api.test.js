"use strict";

const assert = require("node:assert/strict");
const Module = require("node:module");
const path = require("node:path");

function clone(value) {
  return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
}

function matches(document, criteria) {
  return Object.entries(criteria || {}).every(([key, expected]) => {
    const actual = document[key];
    if (expected && expected.__operator === "in") {
      return Array.isArray(actual) && actual.some((item) => expected.values.includes(item));
    }
    return actual === expected;
  });
}

function createMemoryDatabase() {
  const collections = new Map();
  let nextId = 1;

  function records(name) {
    if (!collections.has(name)) collections.set(name, new Map());
    return collections.get(name);
  }

  function collection(name) {
    const table = records(name);
    return {
      doc(id) {
        return {
          async get() {
            if (!table.has(id)) throw new Error("DOCUMENT_NOT_FOUND");
            return { data: clone(table.get(id)) };
          },
          async set({ data }) {
            table.set(id, { _id: id, ...clone(data) });
            return { _id: id };
          },
          async update({ data }) {
            if (!table.has(id)) throw new Error("DOCUMENT_NOT_FOUND");
            table.set(id, { ...table.get(id), ...clone(data), _id: id });
            return { updated: 1 };
          },
          async remove() {
            const deleted = table.delete(id);
            return { removed: deleted ? 1 : 0 };
          },
        };
      },
      async add({ data }) {
        const id = `${name}-${nextId}`;
        nextId += 1;
        table.set(id, { _id: id, ...clone(data) });
        return { _id: id };
      },
      where(criteria) {
        let limitValue = Infinity;
        let skipValue = 0;
        let order = null;
        const query = {
          limit(value) {
            limitValue = value;
            return query;
          },
          skip(value) {
            skipValue = value;
            return query;
          },
          orderBy(field, direction) {
            order = { field, direction };
            return query;
          },
          async get() {
            let data = [...table.values()].filter((document) => matches(document, criteria));
            if (order) {
              const multiplier = order.direction === "desc" ? -1 : 1;
              data.sort((left, right) => multiplier * ((left[order.field] || 0) - (right[order.field] || 0)));
            }
            return { data: clone(data.slice(skipValue, skipValue + limitValue)) };
          },
        };
        return query;
      },
    };
  }

  return {
    command: { in: (values) => ({ __operator: "in", values }) },
    serverDate: () => "2026-08-24T10:00:00.000Z",
    collection,
    runTransaction: async (callback) => callback({ collection }),
    seed(name, id, data) {
      records(name).set(id, { _id: id, ...clone(data) });
    },
    read(name, id) {
      return clone(records(name).get(id));
    },
    all(name) {
      return clone([...records(name).values()]);
    },
  };
}

function loadFactory() {
  const originalLoad = Module._load;
  Module._load = function patchedLoad(request, parent, isMain) {
    if (request === "wx-server-sdk") {
      return {
        DYNAMIC_CURRENT_ENV: "test",
        init() {},
        database() {
          return createMemoryDatabase();
        },
        getWXContext() {
          return { OPENID: "production-wrapper-test" };
        },
      };
    }
    return originalLoad.call(this, request, parent, isMain);
  };
  try {
    const modulePath = path.resolve(__dirname, "../cloudfunctions/familyApi/index.js");
    delete require.cache[modulePath];
    return require(modulePath).createFamilyApi;
  } finally {
    Module._load = originalLoad;
  }
}

function createFixture() {
  const createFamilyApi = loadFactory();
  assert.equal(typeof createFamilyApi, "function", "familyApi must expose an offline-testable handler factory");
  const database = createMemoryDatabase();
  let openId = "owner-openid";
  let unique = 0;
  const main = createFamilyApi({
    database,
    getWXContext: () => ({ OPENID: openId }),
    now: () => "2026-08-24T10:00:00.000Z",
    uniqueId: () => `request-${++unique}`,
    logger: { error() {} },
  });
  return {
    database,
    main,
    asOpenId(value) {
      openId = value;
    },
  };
}

async function createFamily(fixture) {
  const created = await fixture.main({ action: "createFamily" });
  assert.equal(created.ok, true);
  assert.equal(created.created, true);
  return created.family.familyId;
}

async function save(fixture, familyId, expectedVersion, data) {
  return fixture.main({ action: "save", familyId, expectedVersion, data });
}

async function preservesExistingFamilyActions() {
  const fixture = createFixture();
  const familyId = await createFamily(fixture);

  const bootstrap = await fixture.main({ action: "bootstrap" });
  assert.equal(bootstrap.ok, true);
  assert.equal(bootstrap.joined, true);
  assert.equal(bootstrap.family.familyId, familyId);

  const firstSave = await save(fixture, familyId, 0, { profile: { name: "虚构宝宝" } });
  assert.deepEqual(
    { ok: firstSave.ok, saved: firstSave.saved, version: firstSave.version },
    { ok: true, saved: true, version: 1 },
  );

  const loaded = await fixture.main({ action: "load", familyId });
  assert.equal(loaded.ok, true);
  assert.equal(loaded.snapshot.version, 1);
  assert.equal(loaded.snapshot.data.profile.name, "虚构宝宝");

  const status = await fixture.main({ action: "getStatus", familyId });
  assert.equal(status.ok, true);
  assert.equal(status.joined, true);
  assert.equal(status.family.memberCount, 1);
}

async function savesAreRecoverableAndExportable() {
  const fixture = createFixture();
  const familyId = await createFamily(fixture);
  assert.equal((await save(fixture, familyId, 0, { note: "第一版" })).ok, true);
  assert.equal((await save(fixture, familyId, 1, { note: "第二版" })).ok, true);

  const backups = await fixture.main({ action: "listBackups", familyId });
  assert.equal(backups.ok, true);
  assert.deepEqual(backups.backups.map((item) => item.version), [2, 1]);
  assert.equal(backups.backups[0].reason, "save");
  assert.equal(backups.backups[0].byteLength > 0, true);

  const exported = await fixture.main({ action: "exportFamily", familyId });
  assert.equal(exported.ok, true);
  assert.equal(exported.export.format, "baby-care-family-export-v1");
  assert.equal(exported.export.snapshot.version, 2);
  assert.equal(exported.export.snapshot.data.note, "第二版");
  assert.match(exported.export.snapshot.checksumSha256, /^[a-f0-9]{64}$/);
  assert.equal("inviteCode" in exported.export.family, false);
  assert.equal(exported.capacity.snapshotLimitBytes, 850000);
}

async function ownerCanRestoreAndCurrentVersionIsProtectedFirst() {
  const fixture = createFixture();
  const familyId = await createFamily(fixture);
  await save(fixture, familyId, 0, { note: "恢复目标" });
  await save(fixture, familyId, 1, { note: "恢复前的当前值" });
  const listed = await fixture.main({ action: "listBackups", familyId });
  const target = listed.backups.find((item) => item.version === 1);

  const restored = await fixture.main({
    action: "restoreBackup",
    familyId,
    backupId: target.backupId,
    expectedVersion: 2,
  });
  assert.deepEqual(
    { ok: restored.ok, restored: restored.restored, version: restored.version, restoredFromVersion: restored.restoredFromVersion },
    { ok: true, restored: true, version: 3, restoredFromVersion: 1 },
  );

  const loaded = await fixture.main({ action: "load", familyId });
  assert.equal(loaded.snapshot.version, 3);
  assert.equal(loaded.snapshot.data.note, "恢复目标");

  const afterRestore = await fixture.main({ action: "listBackups", familyId });
  assert.equal(afterRestore.backups.some((item) => item.version === 2 && item.reason === "pre_restore"), true);
  assert.equal(afterRestore.backups.some((item) => item.version === 3 && item.reason === "restore"), true);
}

async function restoreRejectsStaleVersionAndUnauthorizedCaller() {
  const fixture = createFixture();
  const familyId = await createFamily(fixture);
  await save(fixture, familyId, 0, { note: "不应被改变" });
  const listed = await fixture.main({ action: "listBackups", familyId });
  const backupId = listed.backups[0].backupId;

  const stale = await fixture.main({ action: "restoreBackup", familyId, backupId, expectedVersion: 0 });
  assert.equal(stale.ok, false);
  assert.equal(stale.error.code, "VERSION_CONFLICT");

  fixture.asOpenId("other-openid");
  const forbiddenList = await fixture.main({ action: "listBackups", familyId });
  assert.equal(forbiddenList.error.code, "FORBIDDEN");
  const forbiddenExport = await fixture.main({ action: "exportFamily", familyId });
  assert.equal(forbiddenExport.error.code, "FORBIDDEN");
  const forbiddenRestore = await fixture.main({ action: "restoreBackup", familyId, backupId, expectedVersion: 1 });
  assert.equal(forbiddenRestore.error.code, "FORBIDDEN");

  fixture.asOpenId("owner-openid");
  const loaded = await fixture.main({ action: "load", familyId });
  assert.equal(loaded.snapshot.version, 1);
  assert.equal(loaded.snapshot.data.note, "不应被改变");
}

async function nonOwnerMemberCanReadBackupsButCannotRestore() {
  const fixture = createFixture();
  const familyId = await createFamily(fixture);
  const created = await save(fixture, familyId, 0, { note: "家庭数据" });
  assert.equal(created.ok, true);
  const ownerStatus = await fixture.main({ action: "getStatus", familyId });

  fixture.asOpenId("member-openid");
  const joined = await fixture.main({ action: "join", inviteCode: ownerStatus.family.inviteCode });
  assert.equal(joined.ok, true);
  const backups = await fixture.main({ action: "listBackups", familyId });
  assert.equal(backups.ok, true);
  const exported = await fixture.main({ action: "exportFamily", familyId });
  assert.equal(exported.ok, true);
  const restore = await fixture.main({
    action: "restoreBackup",
    familyId,
    backupId: backups.backups[0].backupId,
    expectedVersion: 1,
  });
  assert.equal(restore.ok, false);
  assert.equal(restore.error.code, "OWNER_REQUIRED");
}

async function rollingRetentionKeepsOnlyThirtyRecoverableVersions() {
  const fixture = createFixture();
  const familyId = await createFamily(fixture);
  for (let version = 0; version < 35; version += 1) {
    const result = await save(fixture, familyId, version, { version: version + 1 });
    assert.equal(result.ok, true);
  }

  const listed = await fixture.main({ action: "listBackups", familyId, limit: 100 });
  assert.equal(listed.backups.length, 30);
  assert.deepEqual(listed.backups.map((item) => item.version), Array.from({ length: 30 }, (_, index) => 35 - index));
  assert.equal(fixture.database.all("family_backups").length, 30);
}

async function oversizedOrCorruptBackupCannotBeRestored() {
  const fixture = createFixture();
  const familyId = await createFamily(fixture);
  await save(fixture, familyId, 0, { note: "稳定数据" });

  fixture.database.seed("family_backups", "bad-version", {
    familyId,
    version: -1,
    data: { note: "坏备份" },
    byteLength: 10,
    reason: "save",
  });
  const invalidVersion = await fixture.main({
    action: "restoreBackup",
    familyId,
    backupId: "bad-version",
    expectedVersion: 1,
  });
  assert.equal(invalidVersion.error.code, "INVALID_BACKUP");

  fixture.database.seed("family_backups", "too-large", {
    familyId,
    version: 1,
    data: { text: "x".repeat(850000) },
    byteLength: 850011,
    reason: "save",
  });
  const tooLarge = await fixture.main({
    action: "restoreBackup",
    familyId,
    backupId: "too-large",
    expectedVersion: 1,
  });
  assert.equal(tooLarge.error.code, "BACKUP_TOO_LARGE");

  const loaded = await fixture.main({ action: "load", familyId });
  assert.equal(loaded.snapshot.version, 1);
  assert.equal(loaded.snapshot.data.note, "稳定数据");
}

async function capacityStatusWarnsBeforeTheCompatibilityLimit() {
  const fixture = createFixture();
  const familyId = await createFamily(fixture);
  const payload = { text: "x".repeat(700000) };
  const saved = await save(fixture, familyId, 0, payload);
  assert.equal(saved.ok, true);
  assert.equal(saved.capacity.snapshotBytes > 700000, true);
  assert.equal(saved.capacity.warning, true);
  assert.equal(saved.capacity.storageFormat, "legacy-snapshot-v1");

  const tooLarge = await save(fixture, familyId, 1, { text: "x".repeat(850000) });
  assert.equal(tooLarge.ok, false);
  assert.equal(tooLarge.error.code, "SNAPSHOT_TOO_LARGE");
}

async function run() {
  const tests = [
    preservesExistingFamilyActions,
    savesAreRecoverableAndExportable,
    ownerCanRestoreAndCurrentVersionIsProtectedFirst,
    restoreRejectsStaleVersionAndUnauthorizedCaller,
    nonOwnerMemberCanReadBackupsButCannotRestore,
    rollingRetentionKeepsOnlyThirtyRecoverableVersions,
    oversizedOrCorruptBackupCannotBeRestored,
    capacityStatusWarnsBeforeTheCompatibilityLimit,
  ];
  for (const test of tests) {
    await test();
    console.log(`✓ ${test.name}`);
  }
  console.log(`Family API backup tests: ${tests.length}/${tests.length} passed`);
}

run().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
