"use strict";

const assert = require("assert");

const mediaPath = require.resolve("../miniprogram/lib/media");

function createWxMock() {
  const storage = new Map();
  const calls = { uploads: [], cloudDeletes: [], localDeletes: [] };
  const api = {
    saveFile(options) {
      options.success({ savedFilePath: "wxfile://usr/saved-" + String(options.tempFilePath).split("/").pop() });
    },
    removeSavedFile(options) {
      calls.localDeletes.push(options.filePath);
      options.success({});
    },
    getStorageSync(key) { return storage.get(key); },
    setStorageSync(key, value) { storage.set(key, JSON.parse(JSON.stringify(value))); },
    cloud: {
      callFunction(options) {
        options.success({ result: { ok: true, openId: "test-openid" } });
      },
      uploadFile(options) {
        calls.uploads.push({ cloudPath: options.cloudPath, filePath: options.filePath });
        options.success({ fileID: "cloud://test/" + calls.uploads.length });
      },
      deleteFile(options) {
        calls.cloudDeletes.push(...options.fileList);
        options.success({ fileList: options.fileList.map((fileID) => ({ fileID, status: 0 })) });
      },
    },
  };
  return { api, calls, storage };
}

function freshMedia(wxMock) {
  delete require.cache[mediaPath];
  global.wx = wxMock;
  return require(mediaPath);
}

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

test("云文件和本机文件使用对应的删除接口", async function () {
  const mock = createWxMock();
  const media = freshMedia(mock.api);
  await media.deleteMedia("cloud://test/photo-1");
  await media.deleteMedia("wxfile://usr/photo-2.jpg");
  assert.deepStrictEqual(mock.calls.cloudDeletes, ["cloud://test/photo-1"]);
  assert.deepStrictEqual(mock.calls.localDeletes, ["wxfile://usr/photo-2.jpg"]);
});

test("媒体删除失败会进入重试队列，恢复后可清空", async function () {
  const mock = createWxMock();
  let shouldFail = true;
  mock.api.cloud.deleteFile = function (options) {
    if (shouldFail) return options.fail(new Error("offline"));
    mock.calls.cloudDeletes.push(...options.fileList);
    options.success({ fileList: [] });
  };
  const media = freshMedia(mock.api);
  const first = await media.deleteMedia("cloud://test/retry-1");
  assert.strictEqual(first.deleted, false);
  assert.deepStrictEqual(media.getCleanupQueue(), ["cloud://test/retry-1"]);
  shouldFail = false;
  const result = await media.flushCleanupQueue();
  assert.strictEqual(result.remaining, 0);
  assert.deepStrictEqual(media.getCleanupQueue(), []);
  assert.deepStrictEqual(mock.calls.cloudDeletes, ["cloud://test/retry-1"]);
});

test("记录保存失败时清理新上传文件，不删旧文件", async function () {
  const mock = createWxMock();
  const media = freshMedia(mock.api);
  await assert.rejects(function () {
    return media.commitChange({
      originalRefs: ["cloud://test/old"],
      currentRefs: ["cloud://test/new"],
      persist: async function () { throw new Error("save failed"); },
    });
  }, /save failed/);
  assert.deepStrictEqual(mock.calls.cloudDeletes, ["cloud://test/new"]);
});

test("记录保存成功后清理已被替换的旧文件", async function () {
  const mock = createWxMock();
  const media = freshMedia(mock.api);
  const value = await media.commitChange({
    originalRefs: ["cloud://test/old"],
    currentRefs: ["cloud://test/new"],
    persist: async function () { return { ok: true }; },
  });
  assert.deepStrictEqual(value, { ok: true });
  assert.deepStrictEqual(mock.calls.cloudDeletes, ["cloud://test/old"]);
});

test("仍被其他记录引用的共享媒体不会被误删", async function () {
  const mock = createWxMock();
  const media = freshMedia(mock.api);
  const remainingSnapshot = {
    baby: { avatarId: "" },
    memories: [{ id: "m2", assetId: "cloud://test/shared" }],
    abilities: [],
    musicTracks: [],
    stories: [],
    learningItems: [],
  };
  await media.commitChange({
    originalRefs: ["cloud://test/shared"],
    currentRefs: ["cloud://test/new"],
    persist: async function () { return remainingSnapshot; },
  });
  await media.removeWithMedia({
    refs: ["cloud://test/shared"],
    persist: async function () { return remainingSnapshot; },
  });
  assert.deepStrictEqual(mock.calls.cloudDeletes, [], "共享文件仍有引用时必须保留");
});

test("删除记录成功后才删媒体，数据删除失败时保留文件", async function () {
  const mock = createWxMock();
  const media = freshMedia(mock.api);
  await assert.rejects(function () {
    return media.removeWithMedia({
      refs: ["cloud://test/keep"],
      persist: async function () { throw new Error("remove failed"); },
    });
  }, /remove failed/);
  assert.deepStrictEqual(mock.calls.cloudDeletes, []);
  await media.removeWithMedia({
    refs: ["cloud://test/remove"],
    persist: async function () { return "removed"; },
  });
  assert.deepStrictEqual(mock.calls.cloudDeletes, ["cloud://test/remove"]);
});

test("开启云端后会把历史本机媒体迁移为跨设备可用的云文件", async function () {
  const mock = createWxMock();
  const media = freshMedia(mock.api);
  media.configure({ useCloud: true, envId: "test-env" });
  const snapshot = {
    baby: { avatarId: "wxfile://usr/avatar.jpg" },
    memories: [{ id: "m1", assetId: "wxfile://usr/memory.jpg" }],
    abilities: [{ id: "a1", imageId: "wxfile://usr/memory.jpg" }],
    musicTracks: [{ id: "t1", assetId: "wxfile://usr/song.mp3", coverId: "/assets/default.webp" }],
    stories: [{ id: "s1", coverId: "" }],
    learningItems: [{ id: "l1", imageId: "cloud://existing/image" }],
  };
  const result = await media.migrateSnapshotMedia(snapshot);
  assert.strictEqual(result.changed, true);
  assert.strictEqual(mock.calls.uploads.length, 3, "重复的本地图片应只上传一次");
  assert.ok(result.data.baby.avatarId.startsWith("cloud://"));
  assert.strictEqual(result.data.memories[0].assetId, result.data.abilities[0].imageId);
  assert.strictEqual(result.data.learningItems[0].imageId, "cloud://existing/image");
  assert.strictEqual(result.data.musicTracks[0].coverId, "/assets/default.webp");
  assert.deepStrictEqual(result.originalRefs.sort(), [
    "wxfile://usr/avatar.jpg", "wxfile://usr/memory.jpg", "wxfile://usr/song.mp3",
  ].sort());
  assert.strictEqual(result.currentRefs.length, 3);
});

(async function run() {
  for (const item of tests) {
    try {
      await item.fn();
      process.stdout.write("✓ " + item.name + "\n");
    } catch (error) {
      process.stderr.write("✗ " + item.name + "\n" + error.stack + "\n");
      process.exitCode = 1;
    }
  }
  delete global.wx;
  if (process.exitCode) process.exit(process.exitCode);
})().catch(function (error) {
  delete global.wx;
  console.error(error);
  process.exit(1);
});
