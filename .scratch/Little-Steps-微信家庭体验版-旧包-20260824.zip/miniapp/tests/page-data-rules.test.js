"use strict";

const assert = require("assert");
const fs = require("node:fs");
const path = require("path");
const { createSeedData } = require("../miniprogram/lib/model");

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

let toasts = [];
let modals = [];
let writtenFiles = [];
let sharedFiles = [];
global.wx = {
  showToast: function (options) { toasts.push(options || {}); },
  showModal: function (options) {
    modals.push(options || {});
    if (options && typeof options.success === "function") options.success({ confirm: true, cancel: false });
  },
  showLoading: function () {},
  hideLoading: function () {},
  env: { USER_DATA_PATH: "/virtual-user-data" },
  getFileSystemManager: function () {
    return {
      writeFile: function (options) {
        writtenFiles.push({ filePath: options.filePath, data: options.data, encoding: options.encoding });
        options.success({});
      },
    };
  },
  shareFileMessage: function (options) {
    sharedFiles.push({ filePath: options.filePath, fileName: options.fileName });
    options.success({});
  },
  reLaunch: function () {},
};

function replaceModule(modulePath, exportsValue) {
  const resolved = require.resolve(modulePath);
  const previous = require.cache[resolved];
  require.cache[resolved] = { id: resolved, filename: resolved, loaded: true, exports: exportsValue };
  return function restore() {
    if (previous) require.cache[resolved] = previous;
    else delete require.cache[resolved];
  };
}

function setAtPath(target, key, value) {
  const parts = key.split(".");
  let cursor = target;
  parts.slice(0, -1).forEach(function (part) {
    if (!cursor[part] || typeof cursor[part] !== "object") cursor[part] = {};
    cursor = cursor[part];
  });
  cursor[parts[parts.length - 1]] = value;
}

function loadPage(relativePage, store) {
  const pagePath = path.resolve(__dirname, "../miniprogram/pages", relativePage, "index.js");
  const restoreStore = replaceModule("../miniprogram/lib/store", store);
  const restoreLayout = replaceModule("../miniprogram/lib/layout", { getHeaderLayout: function () { return { totalHeight: 88 }; } });
  const restoreMedia = replaceModule("../miniprogram/lib/media", {
    commitChange: function (options) { return options.persist(); },
    discardDraft: function () { return Promise.resolve([]); },
    removeWithMedia: function (options) { return options.persist(); },
    mediaPath: function (result) { return result && (result.fileID || result.savedFilePath) || ""; },
  });
  let definition;
  global.Page = function (value) { definition = value; };
  delete require.cache[pagePath];
  require(pagePath);
  delete require.cache[pagePath];
  restoreStore(); restoreLayout(); restoreMedia();

  const instance = {
    data: JSON.parse(JSON.stringify(definition.data)),
    setData: function (updates, callback) {
      Object.keys(updates || {}).forEach((key) => setAtPath(this.data, key, updates[key]));
      if (callback) callback.call(this);
    },
  };
  Object.keys(definition).forEach(function (key) {
    if (typeof definition[key] === "function") instance[key] = definition[key].bind(instance);
  });
  return instance;
}

function storeStub(data, upsert) {
  return {
    getData: function () { return data; },
    upsert: upsert || function () { return Promise.resolve(); },
    remove: function () { return Promise.resolve(); },
    subscribe: function () { return function () {}; },
    getSyncStatus: function () { return { mode: "local" }; },
  };
}

test("成长页保存等待 Store，失败时保留编辑状态并提示", async function () {
  const data = createSeedData("2026-08-24T10:00:00+08:00");
  let rejectSave;
  const pending = new Promise(function (_, reject) { rejectSave = reject; });
  const page = loadPage("growth", storeStub(data, function () { return pending; }));
  page.data.today = "2026-08-24";
  page.data.editor = { open: true, id: "", isBirth: false, date: "2026-08-20", height: "52", weight: "3.8", note: "测试" };
  toasts = [];
  const saving = page.saveRecord();
  assert.ok(saving && typeof saving.then === "function", "保存方法必须返回可等待的 Promise");
  assert.strictEqual(page.data.editor.open, true, "保存完成前不得关闭编辑框");
  rejectSave(new Error("云端保存失败"));
  await saving;
  assert.strictEqual(page.data.editor.open, true, "保存失败后必须保留编辑内容");
  assert.ok(toasts.some(function (item) { return /失败/.test(item.title); }));
});

test("健康页保存等待 Store，失败时保留编辑状态并提示", async function () {
  const data = createSeedData("2026-08-24T10:00:00+08:00");
  let rejectSave;
  const pending = new Promise(function (_, reject) { rejectSave = reject; });
  const page = loadPage("health", storeStub(data, function () { return pending; }));
  page.data.today = "2026-08-24";
  page.data.editor = { open: true, kind: "ability", id: "", date: "2026-08-20", name: "测试抬头", description: "测试", imageId: "" };
  toasts = [];
  const saving = page.saveEditor();
  assert.ok(saving && typeof saving.then === "function", "保存方法必须返回可等待的 Promise");
  assert.strictEqual(page.data.editor.open, true, "保存完成前不得关闭编辑框");
  rejectSave(new Error("云端保存失败"));
  await saving;
  assert.strictEqual(page.data.editor.open, true, "保存失败后必须保留编辑内容");
  assert.ok(toasts.some(function (item) { return /失败/.test(item.title); }));
});

test("首页成长编辑使用共享范围校验", async function () {
  const data = createSeedData("2026-08-24T10:00:00+08:00");
  let writes = 0;
  const page = loadPage("home", storeStub(data, function () { writes += 1; return Promise.resolve(); }));
  page.data.editorOpen = true;
  page.data.editorKind = "growth";
  page.data.editorId = "";
  page.data.draft = { date: "2026-08-20", height: "250", weight: "3.8", note: "测试" };
  await page.saveEditor();
  assert.strictEqual(writes, 0);
  assert.strictEqual(page.data.editorOpen, true);
});

test("回忆日期不能早于出生或晚于今天", async function () {
  const data = createSeedData("2026-08-24T10:00:00+08:00");
  let writes = 0;
  const page = loadPage("memory", storeStub(data, function () { writes += 1; return Promise.resolve(); }));
  page.data.editorOpen = true;
  page.data.draft = { type: "moment", title: "测试回忆", date: "2026-08-25", description: "虚构测试内容", assetId: "" };
  await page.saveRecord();
  assert.strictEqual(writes, 0);
  assert.strictEqual(page.data.editorOpen, true);
});

test("健康页只显示已选择的疫苗替代路径", function () {
  const data = createSeedData("2026-08-24T10:00:00+08:00");
  data.vaccines.find(function (item) { return item.scheduleKey === "2m-pentavalent-1"; }).completedDate = "2026-10-04";
  const page = loadPage("health", storeStub(data));
  page.refresh();
  const group = page.data.vaccineGroups.find(function (item) { return item.label === "2月龄"; });
  assert.ok(group);
  assert.strictEqual(group.items.some(function (item) { return item.scheduleKey === "2m-pentavalent-1"; }), true);
  assert.strictEqual(group.items.some(function (item) { return item.scheduleKey === "2m-polio-1"; }), false);
});

test("首页备份刷新失败会清空旧列表并禁用旧恢复入口", async function () {
  const data = createSeedData("2026-08-24T10:00:00+08:00");
  const store = storeStub(data);
  store.getSyncStatus = function () { return { mode: "cloud", family: { familyId: "family-1", owner: true } }; };
  store.listBackups = function () { return Promise.reject(new Error("模拟列表读取失败")); };
  const page = loadPage("home", store);
  page.data.syncInfo = store.getSyncStatus();
  page.data.backups = [{ backupId: "stale-backup", version: 2 }];
  await page.loadBackups();
  assert.deepStrictEqual(page.data.backups, [], "刷新失败后旧备份不能继续显示为可恢复");
  assert.ok(/失败/.test(page.data.backupError));
});

test("首页导出使用固定文件名覆盖并明确为离线存档", async function () {
  const data = createSeedData("2026-08-24T10:00:00+08:00");
  const store = storeStub(data);
  store.exportFamily = function () {
    return Promise.resolve({ format: "baby-care-family-export-v1", snapshot: { version: 1, data: {} } });
  };
  writtenFiles = [];
  sharedFiles = [];
  toasts = [];
  const page = loadPage("home", store);
  await page.exportFamilyData();
  assert.strictEqual(writtenFiles.length, 1);
  assert.strictEqual(writtenFiles[0].filePath, "/virtual-user-data/Little-Steps-家庭数据存档.json");
  assert.deepStrictEqual(sharedFiles[0], {
    filePath: "/virtual-user-data/Little-Steps-家庭数据存档.json",
    fileName: "Little-Steps-家庭数据存档.json",
  });
  assert.ok(toasts.some(function (item) { return /存档/.test(item.title); }));

  const template = fs.readFileSync(path.resolve(__dirname, "../miniprogram/pages/home/index.wxml"), "utf8");
  assert.ok(template.includes("导出存档仅供离线保存，当前不能直接导入恢复。"));
});

test("云端恢复已提交但本机重载失败时给出明确恢复提示", async function () {
  const data = createSeedData("2026-08-24T10:00:00+08:00");
  const store = storeStub(data);
  store.restoreBackup = function () {
    const error = new Error("云端备份已恢复，本机数据尚未重新载入；请重新进入小程序");
    error.code = "RESTORE_REFRESH_REQUIRED";
    error.restoreCommitted = true;
    return Promise.reject(error);
  };
  modals = [];
  toasts = [];
  const page = loadPage("home", store);
  page.data.backups = [{ backupId: "backup-v3", dateLabel: "2026.08.23 10:00" }];
  await page.restoreFamilyBackup({ currentTarget: { dataset: { id: "backup-v3" } } });
  assert.strictEqual(modals.length, 2, "第一次确认恢复，第二次说明云端已恢复但本机需重载");
  assert.strictEqual(modals[1].title, "云端已恢复");
  assert.ok(/重新进入小程序/.test(modals[1].content));
  assert.ok(/不会上传旧数据/.test(modals[1].content));
  assert.strictEqual(toasts.length, 0, "不能再显示‘当前内容未变更’这类错误提示");
});

(async function run() {
  for (const item of tests) {
    try {
      await item.fn();
      process.stdout.write("✓ " + item.name + "\n");
    } catch (error) {
      process.stderr.write("✗ " + item.name + "\n" + error.stack + "\n");
      process.exitCode = 1;
    }
  }
  if (process.exitCode) process.exit(process.exitCode);
}());
