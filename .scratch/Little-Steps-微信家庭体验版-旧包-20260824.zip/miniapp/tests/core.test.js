"use strict";

const assert = require("assert");
const { VACCINE_SCHEDULE } = require("../miniprogram/lib/constants");
const { createSeedData } = require("../miniprogram/lib/model");
const derive = require("../miniprogram/lib/derive");
const validation = require("../miniprogram/lib/validation");

function test(name, fn) {
  try { fn(); process.stdout.write("✓ " + name + "\n"); }
  catch (error) { process.stderr.write("✗ " + name + "\n" + error.stack + "\n"); process.exitCode = 1; }
}

test("疫苗清单保留 43 针", function () {
  assert.strictEqual(VACCINE_SCHEDULE.length, 43);
  const seed = createSeedData("2026-08-10T12:00:00+08:00");
  assert.strictEqual(seed.vaccines.length, 43);
  assert.strictEqual(seed.vaccines[0].dueDate, "2026-08-04");
  assert.strictEqual(seed.vaccines[2].dueDate, "2026-09-04");
});

test("正式首次启动只保留固定资料、疫苗参考与静态学习内容", function () {
  const seed = createSeedData("2026-08-10T12:00:00+08:00");
  [
    "feedings", "sleeps", "diapers", "supplements", "todos", "memories",
    "abilities", "checkups", "musicTracks", "stories",
  ].forEach(function (collection) {
    assert.deepStrictEqual(seed[collection], [], collection + " 不应包含演示业务记录");
  });
  assert.deepStrictEqual(seed.baby, {
    name: "硕之", birthDate: "2026-08-04", birthWeight: 2.4, birthHeight: 48,
  });
  assert.deepStrictEqual(seed.growthRecords, [
    { id: "birth-growth", date: "2026-08-04", height: 48, weight: 2.4, note: "出生记录" },
  ]);
  assert.strictEqual(seed.vaccines.length, 43);
  assert.strictEqual(seed.vaccines.some(function (item) { return Boolean(item.completedDate); }), false);
  assert.strictEqual(seed.learningItems.length, 30);
});

test("疫苗按 16 个年龄阶段分组", function () {
  const groups = derive.groupVaccines(createSeedData("2026-08-10T12:00:00+08:00").vaccines);
  assert.strictEqual(groups.length, 16);
  assert.strictEqual(groups[0].ageLabel, "24小时内");
  assert.strictEqual(groups[15].ageLabel, "6周岁");
});

test("月龄按完整月和余下天数计算", function () {
  const age = derive.babyAge("2026-08-04", "2026-09-16T10:00:00+08:00");
  assert.deepStrictEqual({ months: age.months, days: age.days, totalDays: age.totalDays }, { months: 1, days: 12, totalDays: 43 });
  assert.strictEqual(age.label, "1 months 12 days");
});

test("最近喂养时间按真实间隔呈现", function () {
  assert.strictEqual(derive.relativeTime("2026-08-10T02:00", "2026-08-10T03:15"), "1 hours 15 minutes ago");
  assert.strictEqual(derive.relativeTime("2026-08-10T03:14", "2026-08-10T03:15"), "1 minutes ago");
});

test("今日睡眠去重计算跨午夜和重叠记录", function () {
  const result = derive.totalSleepToday([
    { start: "2026-08-09T23:40", end: "2026-08-10T01:00" },
    { start: "2026-08-10T00:30", end: "2026-08-10T02:00" },
    { start: "2026-08-10T10:00", end: "2026-08-10T10:30" },
  ], "2026-08-10T12:00");
  assert.strictEqual(result.minutes, 150);
  assert.strictEqual(result.label, "150 分钟");
});

test("便便次数和最新记录仅依据今日与全量真实记录", function () {
  const records = [
    { time: "2026-08-09T23:59" }, { time: "2026-08-10T08:20" }, { time: "2026-08-10T17:03" },
  ];
  const result = derive.poopSummary(records, "2026-08-10T20:00");
  assert.strictEqual(result.count, 2);
  assert.strictEqual(result.latestTime, "2026-08-10T17:03");
});

test("Vitamin D 状态识别中英文名称与完成状态", function () {
  const completed = derive.vitaminDStatus([{ name: "Vitamin D", date: "2026-08-10", completed: true }], "2026-08-10T20:00");
  const pending = derive.vitaminDStatus([{ name: "维生素 D", date: "2026-08-09", completed: true }], "2026-08-10T20:00");
  assert.strictEqual(completed.completed, true);
  assert.strictEqual(pending.completed, false);
});

test("成长记录按测量日期升序绘图", function () {
  const sorted = derive.sortGrowthRecords([{ date: "2026-08-10" }, { date: "2026-08-04" }, { date: "2026-08-08" }]);
  assert.deepStrictEqual(sorted.map(function (item) { return item.date; }), ["2026-08-04", "2026-08-08", "2026-08-10"]);
});

test("所有实际记录日期统一限制在出生日至今天", function () {
  const now = "2026-08-24T12:00:00+08:00";
  assert.strictEqual(validation.validateDateInLife("2026-08-04", now, "记录日期").ok, true);
  assert.strictEqual(validation.validateDateInLife("2026-08-24", now, "记录日期").ok, true);
  assert.strictEqual(validation.validateDateInLife("2026-08-03", now, "记录日期").ok, false);
  assert.strictEqual(validation.validateDateInLife("2026-08-25", now, "记录日期").ok, false);
  assert.strictEqual(validation.validateDateInLife("2026-02-31", now, "记录日期").ok, false);
  assert.strictEqual(validation.validateDateTimeInLife("2026-08-24T12:01", now, "记录时间").ok, false);
});

test("首页与成长页共享成长记录范围和同日重复规则", function () {
  const existing = [
    { id: "birth-growth", date: "2026-08-04", height: 48, weight: 2.4 },
    { id: "growth-1", date: "2026-08-10", height: 51, weight: 3.4 },
  ];
  const now = "2026-08-24T12:00:00+08:00";
  assert.strictEqual(validation.validateGrowthRecord({ id: "", date: "2026-08-10", height: "52", weight: "3.8" }, existing, now).ok, false);
  assert.strictEqual(validation.validateGrowthRecord({ id: "", date: "2026-08-11", height: "19", weight: "3.8" }, existing, now).ok, false);
  assert.strictEqual(validation.validateGrowthRecord({ id: "", date: "2026-08-11", height: "52", weight: "51" }, existing, now).ok, false);
  const valid = validation.validateGrowthRecord({ id: "", date: "2026-08-11", height: "52", weight: "3.8", note: "测试" }, existing, now);
  assert.strictEqual(valid.ok, true);
  assert.deepStrictEqual({ date: valid.value.date, height: valid.value.height, weight: valid.value.weight }, { date: "2026-08-11", height: 52, weight: 3.8 });
});

test("已接种替代方案后隐藏同家族未选方案", function () {
  const vaccines = createSeedData("2026-08-10T12:00:00+08:00").vaccines;
  const choice = vaccines.find(function (item) { return item.scheduleKey === "2m-pentavalent-1"; });
  choice.completedDate = "2026-10-04";
  const atTwoMonths = derive.visibleVaccineGroups(vaccines).find(function (group) { return group.ageLabel === "2月龄"; });
  assert.strictEqual(atTwoMonths.items.some(function (item) { return item.scheduleKey === "2m-polio-1"; }), false);
  assert.strictEqual(atTwoMonths.items.some(function (item) { return item.scheduleKey === "2m-pentavalent-1"; }), true);
});

if (process.exitCode) process.exit(process.exitCode);

require("./page-data-rules.test");
