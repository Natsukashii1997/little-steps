"use strict";

const { getHeaderLayout } = require("../../lib/layout");

Component({
  properties: {
    title: { type: String, value: "" },
    pageTitle: { type: String, value: "" },
    home: { type: Boolean, value: false },
    showBack: { type: Boolean, value: false },
    showNotice: { type: Boolean, value: false },
    showShare: { type: Boolean, value: true }
  },
  data: {
    statusBarHeight: 24,
    barHeight: 48,
    rightInset: 12
  },
  lifetimes: {
    attached() {
      this.setData(getHeaderLayout());
    }
  },
  methods: {
    handleBack() {
      const pages = getCurrentPages();
      if (pages.length > 1) {
        wx.navigateBack();
      } else {
        wx.reLaunch({ url: "/pages/home/index" });
      }
      this.triggerEvent("back");
    },
    handleNotice() {
      this.triggerEvent("notice");
    }
  }
});
