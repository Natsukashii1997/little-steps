Component({
  properties: {
    label: { type: String, value: "Add" },
    ariaLabel: { type: String, value: "新增" }
  },
  methods: {
    handleTap() {
      this.triggerEvent("add");
    }
  }
});

