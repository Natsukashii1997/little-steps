const ITEMS = [
  { id: "home", label: "Home", path: "/pages/home/index", icon: "/assets/nav/nav-home.webp" },
  { id: "memory", label: "Memory", path: "/pages/memory/index", icon: "/assets/nav/nav-memory.webp" },
  { id: "growth", label: "Growth", path: "/pages/growth/index", icon: "/assets/nav/nav-growth.webp" },
  { id: "health", label: "Health", path: "/pages/health/index", icon: "/assets/nav/nav-health.webp" },
  { id: "education", label: "Education", path: "/pages/education/index", icon: "/assets/nav/nav-education.webp" },
  { id: "study", label: "Study", path: "/pages/study/index", icon: "/assets/nav/nav-study.webp" }
];

Component({
  properties: {
    activePage: { type: String, value: "home" }
  },
  data: { items: ITEMS },
  methods: {
    navigate(event) {
      const { id, path } = event.currentTarget.dataset;
      if (id === this.data.activePage) return;
      wx.reLaunch({ url: path });
    }
  }
});
