const baseConfig = require("./config");
const store = require("./lib/store");
const media = require("./lib/media");

let localConfig = {};
try {
  localConfig = require("./config.local");
} catch (error) {
  localConfig = {};
}

const config = { ...baseConfig, ...localConfig };
media.configure(config);
let hasShownOnce = false;

async function finishRuntimeSetup() {
  await media.flushCleanupQueue();
  const migration = await media.migrateSnapshotMedia(store.getData());
  if (!migration.changed) return store.getData();
  await media.commitChange({
    originalRefs: migration.originalRefs,
    currentRefs: migration.currentRefs,
    persist: function () {
      return store.mutate(function () { return migration.data; });
    },
  });
  return store.getData();
}

async function initializeRuntime() {
  await store.init({ config });
  try {
    return await finishRuntimeSetup();
  } catch (error) {
    // Business records remain available even if media cleanup or migration is offline.
    console.warn("Little Steps 媒体整理将在下次联网时重试", error);
    return store.getData();
  }
}

App({
  globalData: {
    config,
    store,
    ready: null,
  },

  onLaunch() {
    if (config.useCloud && config.envId && wx.cloud) {
      wx.cloud.init({ env: config.envId, traceUser: true });
    }
    this.globalData.ready = initializeRuntime().catch((error) => {
      console.error("Little Steps 初始化失败", error);
      wx.showToast({ title: "数据初始化失败", icon: "none" });
      return store.getData();
    });
  },

  onShow() {
    if (!hasShownOnce) {
      hasShownOnce = true;
      return;
    }
    if (!config.useCloud || !config.envId || !wx.cloud) return;
    this.globalData.ready = store.init({ config }).then(finishRuntimeSetup).catch((error) => {
      console.error("Little Steps 前台同步失败", error);
      return store.getData();
    });
  },
});
