"use strict";

const store = require("../../lib/store");
const media = require("../../lib/media");
const { getHeaderLayout } = require("../../lib/layout");
const { makeId, dateKey } = require("../../lib/model");
const validation = require("../../lib/validation");

const TYPE_LABELS = { moment: "瞬间", photo: "照片", note: "随记" };
const TYPE_OPTIONS = ["瞬间", "照片", "随记"];
const TYPE_VALUES = ["moment", "photo", "note"];

function memoryDate(value) {
  const parts = String(value || "").split("-").map(Number);
  if (parts.length !== 3 || !parts[0]) return "日期未填写";
  return parts[0] + "年" + parts[1] + "月" + parts[2] + "日";
}

function errorText(error, fallback) {
  return error && (error.errMsg || error.message) || fallback;
}

function displayImage(item) {
  if (item.assetId) return item.assetId;
  if (item.type === "photo") return "/assets/ui/baby-avatar.webp";
  if (item.type === "note") return "/assets/memory/note-bear.webp";
  if (/抬头|翻身|rollover/i.test(item.title || "")) return "/assets/memory/rollover.webp";
  return "/assets/memory/smile.webp";
}

Page({
  data: {
    headerHeight: getHeaderLayout().totalHeight,
    birthDate: "2026-08-04",
    today: validation.todayKey(),
    filters: [
      { value: "all", label: "全部" },
      { value: "moment", label: "瞬间" },
      { value: "photo", label: "照片" },
      { value: "note", label: "随记" },
    ],
    activeFilter: "all",
    records: [],
    totalCount: 0,
    editorOpen: false,
    editorId: "",
    editorTitle: "新增回忆",
    draft: { type: "moment", typeLabel: "瞬间", title: "", date: "", description: "", assetId: "", originalAssetId: "" },
    typeOptions: TYPE_OPTIONS,
    uploading: false,
    saving: false,
  },

  async onLoad() {
    const app = getApp();
    await (app.globalData.ready || store.init());
    this.unsubscribe = store.subscribe(() => this.refresh());
    this.refresh();
  },

  onUnload() {
    if (this.unsubscribe) this.unsubscribe();
  },

  refresh() {
    const memories = (store.getData().memories || []).slice().sort(function (a, b) {
      return String(b.date || "").localeCompare(String(a.date || ""));
    });
    const activeFilter = this.data.activeFilter;
    const visible = memories.filter(function (item) {
      return activeFilter === "all" || item.type === activeFilter;
    }).map(function (item, index) {
      return Object.assign({}, item, {
        typeLabel: TYPE_LABELS[item.type] || "回忆",
        displayDate: memoryDate(item.date),
        imageSrc: displayImage(item),
        tone: item.type === "note" ? "blue" : (index % 2 ? "sage" : "yellow"),
        isPhoto: item.type === "photo",
      });
    });
    this.setData({ records: visible, totalCount: memories.length, today: validation.todayKey() });
  },

  selectFilter(event) {
    const value = event.currentTarget.dataset.value;
    if (!value || value === this.data.activeFilter) return;
    this.setData({ activeFilter: value }, () => this.refresh());
  },

  openAdd() {
    const preferred = this.data.activeFilter === "all" ? "moment" : this.data.activeFilter;
    this.openEditor(null, preferred);
  },

  editRecord(event) {
    const id = event.currentTarget.dataset.id;
    const item = (store.getData().memories || []).find(function (record) { return record.id === id; });
    if (item) this.openEditor(item, item.type || "moment");
  },

  openEditor(item, defaultType) {
    const type = item && item.type || defaultType || "moment";
    this.setData({
      editorOpen: true,
      editorId: item && item.id || "",
      editorTitle: item ? "编辑回忆" : "新增回忆",
      draft: {
        type: type,
        typeLabel: TYPE_LABELS[type] || "瞬间",
        title: item && item.title || "",
        date: item && item.date || dateKey(new Date()),
        description: item && item.description || "",
        assetId: item && item.assetId || "",
        originalAssetId: item && item.assetId || "",
        sourceAbilityId: item && item.sourceAbilityId || "",
      },
    });
  },

  async closeEditor() {
    if (this.data.uploading || this.data.saving) return;
    const draft = this.data.draft || {};
    await media.discardDraft({
      originalRefs: [draft.originalAssetId],
      currentRefs: [draft.assetId],
    });
    this.setData({ editorOpen: false });
  },
  noop() {},

  handleInput(event) {
    this.setData({ ["draft." + event.currentTarget.dataset.field]: event.detail.value });
  },

  handleDate(event) { this.setData({ "draft.date": event.detail.value }); },

  async handleType(event) {
    const index = Number(event.detail.value);
    const type = TYPE_VALUES[index] || "moment";
    const draft = this.data.draft || {};
    const previousDraft = draft.assetId || "";
    const nextAssetId = type === "photo" ? (previousDraft || draft.originalAssetId || "") : "";
    this.setData({ "draft.type": type, "draft.typeLabel": TYPE_LABELS[type], "draft.assetId": nextAssetId });
    if (type !== "photo" && previousDraft) {
      await media.discardDraft({ originalRefs: [draft.originalAssetId], currentRefs: [previousDraft] });
    }
  },

  async choosePhoto() {
    if (this.data.uploading || this.data.saving) return;
    let loadingShown = false;
    try {
      const files = await media.chooseImage({ count: 1 });
      if (!files.length) return;
      if (files[0].size > 12 * 1024 * 1024) throw new Error("照片请控制在 12 MB 以内");
      this.setData({ uploading: true });
      wx.showLoading({ title: "正在保存照片" });
      loadingShown = true;
      const uploaded = await media.uploadImage(files[0]);
      const previousDraft = this.data.draft.assetId;
      this.setData({ "draft.assetId": uploaded.fileID, "draft.type": "photo", "draft.typeLabel": "照片" });
      await media.discardDraft({
        originalRefs: [this.data.draft.originalAssetId],
        currentRefs: [previousDraft],
      });
      wx.showToast({ title: "照片已选择", icon: "success" });
    } catch (error) {
      if (!String(errorText(error, "")).includes("cancel")) wx.showToast({ title: errorText(error, "照片保存失败"), icon: "none" });
    } finally {
      if (loadingShown) wx.hideLoading();
      this.setData({ uploading: false });
    }
  },

  async saveRecord() {
    if (this.data.saving) return;
    const draft = this.data.draft;
    const title = String(draft.title || "").trim();
    const description = String(draft.description || "").trim();
    if (!title || !draft.date || !description) {
      wx.showToast({ title: "请完整填写标题、日期和内容", icon: "none" });
      return;
    }
    const dateResult = validation.validateDateInLife(draft.date, new Date(), "回忆日期");
    if (!dateResult.ok) {
      wx.showToast({ title: dateResult.message, icon: "none" });
      return;
    }
    if (draft.type === "photo" && !draft.assetId && !this.data.editorId) {
      wx.showToast({ title: "请先选择一张宝宝照片", icon: "none" });
      return;
    }
    try {
      this.setData({ saving: true });
      await media.commitChange({
        originalRefs: [draft.originalAssetId],
        currentRefs: [draft.assetId],
        persist: () => store.upsert("memories", {
          id: this.data.editorId || makeId("memory"),
          type: draft.type || "moment",
          title: title,
          date: draft.date,
          description: description,
          assetId: draft.type === "photo" ? draft.assetId || "" : "",
          sourceAbilityId: draft.sourceAbilityId || "",
        }),
      });
      this.setData({ editorOpen: false });
      wx.showToast({ title: "回忆已保存", icon: "success" });
    } catch (error) {
      this.setData({ "draft.assetId": draft.originalAssetId || "" });
      wx.showToast({ title: errorText(error, "保存失败"), icon: "none" });
    } finally {
      this.setData({ saving: false });
    }
  },

  async deleteRecord() {
    if (this.data.saving || this.data.uploading) return;
    const id = this.data.editorId;
    if (!id) return;
    const confirmed = await new Promise(function (resolve) {
      wx.showModal({
        title: "删除这段回忆？",
        content: "删除后无法恢复。关联的健康记录不会被删除。",
        confirmText: "删除",
        confirmColor: "#c96050",
        success: function (result) { resolve(result.confirm); },
      });
    });
    if (!confirmed) return;
    try {
      this.setData({ saving: true });
      const draft = this.data.draft || {};
      await media.removeWithMedia({
        refs: [draft.originalAssetId, draft.assetId],
        persist: function () { return store.remove("memories", id); },
      });
      this.setData({ editorOpen: false });
      wx.showToast({ title: "已删除", icon: "success" });
    } catch (error) {
      wx.showToast({ title: errorText(error, "删除失败，请重试"), icon: "none" });
    } finally {
      this.setData({ saving: false });
    }
  },

  onShareAppMessage() {
    return { title: "硕之的成长回忆", path: "/pages/memory/index" };
  },
});
