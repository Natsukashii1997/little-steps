"use strict";

const store = require("../../lib/store");
const derive = require("../../lib/derive");
const media = require("../../lib/media");
const { getHeaderLayout } = require("../../lib/layout");
const { makeId, dateKey, dateTime } = require("../../lib/model");
const validation = require("../../lib/validation");

const COLLECTION_BY_KIND = {
  feeding: "feedings",
  sleep: "sleeps",
  poop: "diapers",
  growth: "growthRecords",
  todo: "todos",
};

const MANAGER_TITLES = {
  feeding: "喂养记录",
  sleep: "睡眠记录",
  poop: "便便记录",
};

function pad(value) { return String(value).padStart(2, "0"); }
function nowParts(value) {
  const current = value || new Date();
  return { date: dateKey(current), time: pad(current.getHours()) + ":" + pad(current.getMinutes()) };
}
function splitDateTime(value) {
  const date = derive.asDate(value);
  if (isNaN(date.getTime())) return nowParts();
  return { date: dateKey(date), time: pad(date.getHours()) + ":" + pad(date.getMinutes()) };
}
function combineDateTime(day, time) { return String(day || "") + "T" + String(time || "00:00"); }
function formatTime(value) {
  const date = derive.asDate(value);
  return isNaN(date.getTime()) ? "--:--" : pad(date.getHours()) + ":" + pad(date.getMinutes());
}
function formatDateTime(value) {
  const date = derive.asDate(value);
  return isNaN(date.getTime()) ? "暂无时间" : (date.getMonth() + 1) + "月" + date.getDate() + "日 " + formatTime(date);
}
function homeDate(value) {
  const week = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
  return value.getFullYear() + "." + pad(value.getMonth() + 1) + "." + pad(value.getDate()) + " " + week[value.getDay()];
}
function relativeCompact(value, nowValue) {
  const from = derive.asDate(value);
  const now = nowValue || new Date();
  if (isNaN(from.getTime())) return "暂无记录";
  const minutes = Math.max(0, Math.floor((now.getTime() - from.getTime()) / 60000));
  if (minutes < 1) return "刚刚";
  if (minutes < 60) return minutes + "分钟前";
  const hours = Math.floor(minutes / 60);
  const remainder = minutes % 60;
  if (hours < 24) return hours + "小时" + (remainder ? remainder + "分钟前" : "前");
  const days = Math.floor(hours / 24);
  const hourPart = hours % 24;
  return days + "天" + (hourPart ? hourPart + "小时前" : "前");
}
function sortNewest(records, field) {
  return (records || []).slice().sort(function (a, b) {
    return derive.asDate(b[field]).getTime() - derive.asDate(a[field]).getTime();
  });
}
function measurement(value) {
  if (value === undefined || value === null || value === "") return "—";
  return String(Number(Number(value).toFixed(2)));
}
function minutesBetween(startValue, endValue) {
  const start = derive.asDate(startValue).getTime();
  const end = derive.asDate(endValue).getTime();
  return isFinite(start) && isFinite(end) && end > start ? Math.round((end - start) / 60000) : 0;
}
function errorText(error, fallback) {
  return error && (error.errMsg || error.message) || fallback;
}
function cloudDate(value) {
  if (value && typeof value === "object") {
    if (value.$date) return derive.asDate(value.$date);
    if (Number.isFinite(value.seconds)) return new Date(value.seconds * 1000);
    if (Number.isFinite(value._seconds)) return new Date(value._seconds * 1000);
  }
  return derive.asDate(value);
}
function backupDateLabel(value) {
  const date = cloudDate(value);
  if (isNaN(date.getTime())) return "时间未记录";
  return date.getFullYear() + "." + pad(date.getMonth() + 1) + "." + pad(date.getDate())
    + " " + pad(date.getHours()) + ":" + pad(date.getMinutes());
}
function backupReasonLabel(reason) {
  if (reason === "pre_restore") return "恢复前保护";
  if (reason === "restore") return "恢复结果";
  return "自动备份";
}
function byteLabel(value) {
  const bytes = Math.max(0, Number(value) || 0);
  if (bytes < 1024) return Math.round(bytes) + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(bytes < 10240 ? 1 : 0) + " KB";
  return (bytes / 1024 / 1024).toFixed(1) + " MB";
}
function capacityView(value) {
  if (!value || typeof value !== "object") return null;
  const used = Number(value.snapshotBytes !== undefined ? value.snapshotBytes : value.byteLength) || 0;
  const limit = Number(value.snapshotLimitBytes !== undefined ? value.snapshotLimitBytes : value.limitBytes) || 0;
  if (!limit) return null;
  const rawRatio = Number(value.usageRatio !== undefined ? value.usageRatio : value.ratio);
  const ratio = Number.isFinite(rawRatio) ? rawRatio : used / limit;
  return {
    used: byteLabel(used),
    limit: byteLabel(limit),
    percent: Math.min(100, Math.max(0, Math.round(ratio * 1000) / 10)),
    warning: Boolean(value.warning),
  };
}
function writeTextFile(filePath, content) {
  return new Promise(function (resolve, reject) {
    const manager = wx.getFileSystemManager();
    manager.writeFile({ filePath, data: content, encoding: "utf8", success: resolve, fail: reject });
  });
}
function shareFile(filePath, fileName) {
  return new Promise(function (resolve, reject) {
    if (typeof wx.shareFileMessage !== "function") {
      reject(new Error("当前微信版本不支持导出文件，请升级微信后重试"));
      return;
    }
    wx.shareFileMessage({ filePath, fileName, success: resolve, fail: reject });
  });
}

Page({
  data: {
    headerHeight: getHeaderLayout().totalHeight,
    birthDate: "2026-08-04",
    today: validation.todayKey(),
    dateHeading: "",
    baby: { name: "硕之", birthDate: "2026-08-04", birthWeight: 2.4, birthHeight: 48 },
    avatarSrc: "/assets/ui/baby-avatar.webp",
    ageLabel: "0 months 0 days",
    ageMonths: 0,
    ageDays: 0,
    weight: "2.4",
    height: "48",
    feeding: { relative: "暂无记录", time: "--:--", amount: "未记录", milkType: "未记录" },
    sleep: { range: "暂无记录", total: "0 分钟" },
    poop: { latest: "--:--", count: 0 },
    vitamin: { completed: false, label: "今天未服用" },
    todos: [],
    managerOpen: false,
    managerKind: "",
    managerTitle: "",
    managerRecords: [],
    editorOpen: false,
    editorKind: "",
    editorTitle: "",
    editorId: "",
    editorFromManager: false,
    draft: {},
    milkTypes: ["母乳", "配方奶", "混合喂养"],
    poopStatuses: ["正常软便", "偏稀", "偏干", "其他"],
    uploadingAvatar: false,
    editorSaving: false,
    syncOpen: false,
    inviteCodeInput: "",
    syncInfo: { mode: "local", pending: false, error: "", family: null },
    capacityView: null,
    backups: [],
    backupRetention: 30,
    backupLoading: false,
    backupError: "",
    backupActionId: "",
    exportLoading: false,
  },

  async onLoad() {
    const app = getApp();
    await (app.globalData.ready || store.init());
    this.unsubscribe = store.subscribe(() => this.refresh());
    this.refresh();
    this.clock = setInterval(() => this.refresh(), 60000);
  },

  onUnload() {
    if (this.unsubscribe) this.unsubscribe();
    if (this.clock) clearInterval(this.clock);
  },

  refresh() {
    const data = store.getData();
    const now = new Date();
    const syncInfo = store.getSyncStatus();
    const baby = Object.assign({}, data.baby || {}, {
      name: "硕之",
      birthDate: "2026-08-04",
      birthWeight: 2.4,
      birthHeight: 48,
    });
    const age = derive.babyAge("2026-08-04", now);
    const growth = derive.sortGrowthRecords(data.growthRecords);
    const weightRecord = growth.slice().reverse().find(function (item) { return item.weight !== "" && item.weight !== undefined && item.weight !== null; });
    const heightRecord = growth.slice().reverse().find(function (item) { return item.height !== "" && item.height !== undefined && item.height !== null; });
    const feeding = derive.latestBy(data.feedings, "time");
    const sleep = derive.latestBy(data.sleeps, "end");
    const sleepTotal = derive.totalSleepToday(data.sleeps, now);
    const poop = derive.poopSummary(data.diapers, now);
    const vitamin = derive.vitaminDStatus(data.supplements, now);

    this.setData({
      dateHeading: homeDate(now),
      today: validation.todayKey(now),
      baby,
      avatarSrc: baby.avatarId || "/assets/ui/baby-avatar.webp",
      ageLabel: age.label,
      ageMonths: age.months,
      ageDays: age.days,
      weight: measurement(weightRecord && weightRecord.weight),
      height: measurement(heightRecord && heightRecord.height),
      feeding: {
        relative: feeding ? relativeCompact(feeding.time, now) : "暂无记录",
        time: feeding ? formatTime(feeding.time) : "--:--",
        amount: feeding ? feeding.amount + " ml" : "未记录",
        milkType: feeding ? feeding.milkType : "未记录",
      },
      sleep: {
        range: sleep ? formatTime(sleep.start) + "–" + formatTime(sleep.end) : "暂无记录",
        total: sleepTotal.minutes + " 分钟",
      },
      poop: { latest: poop.latest ? formatTime(poop.latest.time) : "--:--", count: poop.count },
      vitamin: { completed: vitamin.completed, label: vitamin.label },
      todos: (data.todos || []).map(function (item) { return Object.assign({}, item); }),
      syncInfo,
      capacityView: capacityView(syncInfo.capacity),
    });

    if (this.data.managerOpen) this.refreshManager();
  },

  async changeAvatar() {
    if (this.data.uploadingAvatar) return;
    let loadingShown = false;
    try {
      const files = await media.chooseImage({ count: 1 });
      if (!files.length) return;
      if (files[0].size > 12 * 1024 * 1024) throw new Error("照片请控制在 12 MB 以内");
      this.setData({ uploadingAvatar: true });
      wx.showLoading({ title: "正在保存照片" });
      loadingShown = true;
      const uploaded = await media.uploadImage(files[0]);
      const originalAvatarId = store.getData().baby && store.getData().baby.avatarId || "";
      await media.commitChange({
        originalRefs: [originalAvatarId],
        currentRefs: [uploaded.fileID],
        persist: function () {
          return store.mutate(function (next) {
            next.baby = Object.assign({}, next.baby, {
              name: "硕之",
              birthDate: "2026-08-04",
              birthWeight: 2.4,
              birthHeight: 48,
              avatarId: uploaded.fileID,
            });
            return next;
          });
        },
      });
      wx.showToast({ title: "头像已保存", icon: "success" });
    } catch (error) {
      if (!String(errorText(error, "")).includes("cancel")) wx.showToast({ title: errorText(error, "照片保存失败"), icon: "none" });
    } finally {
      if (loadingShown) wx.hideLoading();
      this.setData({ uploadingAvatar: false });
    }
  },

  openManager(event) {
    const kind = event.currentTarget.dataset.kind;
    this.openManagerKind(kind);
  },

  openManagerKind(kind) {
    this.setData({ managerOpen: true, managerKind: kind, managerTitle: MANAGER_TITLES[kind] || "记录" });
    this.refreshManager();
  },

  refreshManager() {
    const data = store.getData();
    const kind = this.data.managerKind;
    let records = [];
    if (kind === "feeding") {
      records = sortNewest(data.feedings, "time").map(function (item) {
        return { id: item.id, title: formatDateTime(item.time), detail: item.amount + " ml · " + item.milkType, note: item.note || "" };
      });
    } else if (kind === "sleep") {
      records = sortNewest(data.sleeps, "end").map(function (item) {
        const duration = minutesBetween(item.start, item.end);
        return { id: item.id, title: formatDateTime(item.start), detail: formatTime(item.start) + "–" + formatTime(item.end) + " · " + duration + " 分钟", note: item.note || "" };
      });
    } else if (kind === "poop") {
      records = sortNewest(data.diapers, "time").map(function (item) {
        return { id: item.id, title: formatDateTime(item.time), detail: item.status || "未填写状态", note: item.note || "" };
      });
    }
    this.setData({ managerRecords: records });
  },

  closeManager() { this.setData({ managerOpen: false }); },
  noop() {},

  openSync() {
    const syncInfo = store.getSyncStatus();
    this.setData({ syncOpen: true, syncInfo, capacityView: capacityView(syncInfo.capacity) });
    if (syncInfo.family) this.loadBackups();
  },

  closeSync() { this.setData({ syncOpen: false }); },

  handleInviteInput(event) { this.setData({ inviteCodeInput: String(event.detail.value || "").toUpperCase() }); },

  async createFamily() {
    try {
      wx.showLoading({ title: "正在创建家庭" });
      await store.createFamily();
      const syncInfo = store.getSyncStatus();
      this.setData({ syncInfo, capacityView: capacityView(syncInfo.capacity) });
      await this.loadBackups();
      wx.showToast({ title: "家庭已创建", icon: "success" });
    } catch (error) {
      wx.showToast({ title: errorText(error, "创建家庭失败"), icon: "none" });
    } finally { wx.hideLoading(); }
  },

  async joinFamily() {
    const code = String(this.data.inviteCodeInput || "").trim().toUpperCase();
    if (!/^[A-Z0-9]{6}$/.test(code)) return wx.showToast({ title: "请输入6位邀请码", icon: "none" });
    try {
      wx.showLoading({ title: "正在加入家庭" });
      await store.joinFamily(code);
      const syncInfo = store.getSyncStatus();
      this.setData({ syncInfo, capacityView: capacityView(syncInfo.capacity), inviteCodeInput: "" });
      await this.loadBackups();
      wx.showToast({ title: "已加入家庭", icon: "success" });
    } catch (error) {
      wx.showToast({ title: errorText(error, "加入家庭失败"), icon: "none" });
    } finally { wx.hideLoading(); }
  },

  copyInviteCode() {
    const family = this.data.syncInfo && this.data.syncInfo.family;
    if (!family || !family.inviteCode) return;
    wx.setClipboardData({ data: family.inviteCode });
  },

  async loadBackups() {
    if (this.data.backupLoading || !(this.data.syncInfo && this.data.syncInfo.family)) return;
    this.setData({ backupLoading: true, backupError: "" });
    try {
      const result = await store.listBackups(10);
      const backups = (result.backups || []).map(function (item) {
        return Object.assign({}, item, {
          dateLabel: backupDateLabel(item.createdAt),
          reasonLabel: backupReasonLabel(item.reason),
          sizeLabel: byteLabel(item.byteLength),
        });
      });
      const syncInfo = store.getSyncStatus();
      this.setData({
        backups,
        backupRetention: result.retentionLimit || 30,
        syncInfo,
        capacityView: capacityView(syncInfo.capacity),
      });
    } catch (error) {
      this.setData({
        backups: [],
        backupActionId: "",
        backupError: errorText(error, "备份列表读取失败，请重试"),
      });
    } finally {
      this.setData({ backupLoading: false });
    }
  },

  async exportFamilyData() {
    if (this.data.exportLoading) return;
    let loadingShown = false;
    try {
      this.setData({ exportLoading: true });
      wx.showLoading({ title: "正在生成备份" });
      loadingShown = true;
      const exported = await store.exportFamily();
      const fileName = "Little-Steps-家庭数据存档.json";
      const filePath = wx.env.USER_DATA_PATH + "/" + fileName;
      await writeTextFile(filePath, JSON.stringify(exported, null, 2));
      wx.hideLoading();
      loadingShown = false;
      await shareFile(filePath, fileName);
      const syncInfo = store.getSyncStatus();
      this.setData({ syncInfo, capacityView: capacityView(syncInfo.capacity) });
      wx.showToast({ title: "离线存档已生成", icon: "success" });
    } catch (error) {
      const message = errorText(error, "导出失败，请重试");
      if (!String(message).toLowerCase().includes("cancel")) wx.showToast({ title: message, icon: "none", duration: 2800 });
    } finally {
      if (loadingShown) wx.hideLoading();
      this.setData({ exportLoading: false });
    }
  },

  async restoreFamilyBackup(event) {
    const backupId = event.currentTarget.dataset.id;
    const selected = (this.data.backups || []).find(function (item) { return item.backupId === backupId; });
    if (!selected || this.data.backupActionId) return;
    const confirmed = await new Promise(function (resolve) {
      wx.showModal({
        title: "恢复这份家庭备份？",
        content: "将恢复到 " + selected.dateLabel + " 的内容。当前数据会先自动保留一份保护备份。",
        confirmText: "确认恢复",
        confirmColor: "#b8655b",
        success: function (result) { resolve(result.confirm); },
        fail: function () { resolve(false); },
      });
    });
    if (!confirmed) return;
    let loadingShown = false;
    try {
      this.setData({ backupActionId: backupId });
      wx.showLoading({ title: "正在恢复" });
      loadingShown = true;
      await store.restoreBackup(backupId);
      this.refresh();
      await this.loadBackups();
      wx.showToast({ title: "家庭数据已恢复", icon: "success" });
    } catch (error) {
      if (error && error.code === "RESTORE_REFRESH_REQUIRED") {
        if (loadingShown) {
          wx.hideLoading();
          loadingShown = false;
        }
        wx.showModal({
          title: error.restoreCommitted ? "云端已恢复" : "需要重新载入",
          content: error.restoreCommitted
            ? "云端备份已经恢复，但本机数据暂时未刷新。请关闭并重新进入小程序；刷新完成前不会上传旧数据。"
            : "恢复结果尚未确认。请关闭并重新进入小程序；重新载入完成前不会上传本机旧数据。",
          showCancel: false,
          confirmText: "知道了",
        });
      } else {
        wx.showToast({ title: errorText(error, "恢复失败，当前内容未变更"), icon: "none", duration: 2800 });
      }
    } finally {
      if (loadingShown) wx.hideLoading();
      this.setData({ backupActionId: "" });
    }
  },

  async syncNow() {
    try {
      wx.showLoading({ title: "正在同步" });
      const result = await store.syncNow();
      const syncInfo = store.getSyncStatus();
      this.setData({ syncInfo, capacityView: capacityView(syncInfo.capacity) });
      if (!result || !result.ok || !result.synced) {
        wx.showToast({ title: "云端暂不可用，内容仍安全保存在本机", icon: "none", duration: 2600 });
        return;
      }
      await this.loadBackups();
      wx.showToast({ title: "已同步到家庭云端", icon: "success" });
    } catch (error) {
      wx.showToast({ title: errorText(error, "同步失败"), icon: "none" });
    } finally { wx.hideLoading(); }
  },

  addFromManager() {
    this.openEditor(this.data.managerKind, null, true);
  },

  editManagerRecord(event) {
    const kind = this.data.managerKind;
    const collection = COLLECTION_BY_KIND[kind];
    const item = (store.getData()[collection] || []).find(function (record) { return record.id === event.currentTarget.dataset.id; });
    if (item) this.openEditor(kind, item, true);
  },

  async deleteManagerRecord(event) {
    const kind = this.data.managerKind;
    const id = event.currentTarget.dataset.id;
    const confirmed = await new Promise(function (resolve) {
      wx.showModal({ title: "删除这条记录？", content: "删除后无法恢复。", confirmText: "删除", confirmColor: "#c96050", success: function (result) { resolve(result.confirm); } });
    });
    if (!confirmed) return;
    try {
      await store.remove(COLLECTION_BY_KIND[kind], id);
      this.refreshManager();
      wx.showToast({ title: "已删除", icon: "success" });
    } catch (error) {
      wx.showToast({ title: errorText(error, "删除失败，请重试"), icon: "none" });
    }
  },

  openGrowthEditor() {
    const data = store.getData();
    const today = dateKey(new Date());
    const existing = (data.growthRecords || []).find(function (item) { return item.date === today; });
    this.openEditor("growth", existing || null, false);
  },

  openTodoEditor(event) {
    const id = event && event.currentTarget.dataset.id;
    const item = id ? (store.getData().todos || []).find(function (record) { return record.id === id; }) : null;
    this.openEditor("todo", item || null, false);
  },

  openEditor(kind, item, fromManager) {
    const now = new Date();
    const parts = nowParts(now);
    let draft = {};
    let title = "新增记录";
    if (kind === "feeding") {
      const time = splitDateTime(item && item.time);
      draft = { date: time.date, time: time.time, amount: item ? String(item.amount) : "", milkType: item && item.milkType || "母乳", note: item && item.note || "" };
      title = item ? "编辑喂养" : "新增喂养";
    } else if (kind === "sleep") {
      const startDefault = new Date(now.getTime() - 60 * 60000);
      const start = splitDateTime(item && item.start || startDefault);
      const end = splitDateTime(item && item.end || now);
      draft = { startDate: start.date, startTime: start.time, endDate: end.date, endTime: end.time, note: item && item.note || "" };
      title = item ? "编辑睡眠" : "新增睡眠";
    } else if (kind === "poop") {
      const time = splitDateTime(item && item.time);
      draft = { date: time.date, time: time.time, status: item && item.status || "正常软便", note: item && item.note || "" };
      title = item ? "编辑便便" : "新增便便";
    } else if (kind === "growth") {
      const records = derive.sortGrowthRecords(store.getData().growthRecords);
      const latest = records[records.length - 1] || {};
      draft = { date: item && item.date || parts.date, weight: item && item.weight !== undefined ? String(item.weight) : String(latest.weight || ""), height: item && item.height !== undefined ? String(item.height) : String(latest.height || ""), note: item && item.note || "" };
      title = item ? "修改成长数据" : "填写当前数据";
    } else if (kind === "todo") {
      draft = { title: item && item.title || "" };
      title = item ? "编辑待办" : "新增待办";
    }
    this.setData({
      managerOpen: false,
      editorOpen: true,
      editorKind: kind,
      editorTitle: title,
      editorId: item && item.id || "",
      editorFromManager: Boolean(fromManager),
      draft,
    });
  },

  closeEditor() {
    if (this.data.editorSaving) return;
    const returnToManager = this.data.editorFromManager;
    const kind = this.data.editorKind;
    this.setData({ editorOpen: false });
    if (returnToManager) this.openManagerKind(kind);
  },

  handleDraftInput(event) {
    this.setData({ ["draft." + event.currentTarget.dataset.field]: event.detail.value });
  },

  handleDraftPicker(event) {
    this.setData({ ["draft." + event.currentTarget.dataset.field]: event.detail.value });
  },

  handleOptionPicker(event) {
    const field = event.currentTarget.dataset.field;
    const source = event.currentTarget.dataset.source;
    const options = this.data[source] || [];
    this.setData({ ["draft." + field]: options[Number(event.detail.value)] || "" });
  },

  async saveEditor() {
    if (this.data.editorSaving) return;
    const kind = this.data.editorKind;
    const draft = this.data.draft;
    const id = this.data.editorId || makeId(kind);
    let record;
    try {
      this.setData({ editorSaving: true });
      if (kind === "feeding") {
        const amount = Number(draft.amount);
        if (!isFinite(amount) || amount <= 0) throw new Error("请输入正确的奶量");
        const time = combineDateTime(draft.date, draft.time);
        const timeResult = validation.validateDateTimeInLife(time, new Date(), "喂奶时间");
        if (!timeResult.ok) throw new Error(timeResult.message);
        record = { id, time, amount, milkType: draft.milkType || "母乳", note: String(draft.note || "").trim() };
      } else if (kind === "sleep") {
        const start = combineDateTime(draft.startDate, draft.startTime);
        const end = combineDateTime(draft.endDate, draft.endTime);
        const startResult = validation.validateDateTimeInLife(start, new Date(), "睡眠开始时间");
        const endResult = validation.validateDateTimeInLife(end, new Date(), "睡眠结束时间");
        if (!startResult.ok) throw new Error(startResult.message);
        if (!endResult.ok) throw new Error(endResult.message);
        if (derive.asDate(end) <= derive.asDate(start)) throw new Error("睡眠结束时间必须晚于开始时间");
        record = { id, start, end, note: String(draft.note || "").trim() };
      } else if (kind === "poop") {
        const time = combineDateTime(draft.date, draft.time);
        const timeResult = validation.validateDateTimeInLife(time, new Date(), "便便时间");
        if (!timeResult.ok) throw new Error(timeResult.message);
        record = { id, time, status: draft.status || "正常软便", note: String(draft.note || "").trim() };
      } else if (kind === "growth") {
        const growthResult = validation.validateGrowthRecord(Object.assign({}, draft, { id }), store.getData().growthRecords, new Date());
        if (!growthResult.ok) throw new Error(growthResult.message);
        record = growthResult.value;
      } else if (kind === "todo") {
        const title = String(draft.title || "").trim();
        if (!title) throw new Error("请输入待办内容");
        const previous = (store.getData().todos || []).find(function (item) { return item.id === id; });
        record = { id, title, completed: previous ? Boolean(previous.completed) : false };
      }
      await store.upsert(COLLECTION_BY_KIND[kind], record);
      const returnToManager = this.data.editorFromManager;
      this.setData({ editorOpen: false });
      if (returnToManager) this.openManagerKind(kind);
      wx.showToast({ title: "已保存", icon: "success" });
    } catch (error) {
      wx.showToast({ title: errorText(error, "保存失败"), icon: "none" });
    } finally {
      this.setData({ editorSaving: false });
    }
  },

  async quickPoop() {
    if (this.poopSaving) return;
    this.poopSaving = true;
    try {
      await store.upsert("diapers", { id: makeId("poop"), time: dateTime(new Date()), status: "正常软便", note: "首页快捷记录" });
      wx.showToast({ title: "已记录便便", icon: "success" });
    } catch (error) {
      wx.showToast({ title: errorText(error, "记录失败，请重试"), icon: "none" });
    } finally {
      this.poopSaving = false;
    }
  },

  async toggleVitamin() {
    if (this.vitaminSaving) return;
    this.vitaminSaving = true;
    const data = store.getData();
    const today = dateKey(new Date());
    const existing = (data.supplements || []).find(function (item) {
      return derive.dayKey(item.date) === today && String(item.name || "").replace(/\s+/g, "").toLowerCase().includes("d");
    });
    try {
      await store.upsert("supplements", {
        id: existing && existing.id || makeId("supplement"),
        name: "维生素 D",
        date: today,
        completed: existing ? !existing.completed : true,
      });
      wx.showToast({ title: existing && existing.completed ? "已取消确认" : "今日已确认", icon: "success" });
    } catch (error) {
      wx.showToast({ title: errorText(error, "确认失败，请重试"), icon: "none" });
    } finally {
      this.vitaminSaving = false;
    }
  },

  async toggleTodo(event) {
    const id = event.currentTarget.dataset.id;
    const item = (store.getData().todos || []).find(function (record) { return record.id === id; });
    if (!item) return;
    this.todoSaving = this.todoSaving || new Set();
    if (this.todoSaving.has(id)) return;
    this.todoSaving.add(id);
    try {
      await store.upsert("todos", Object.assign({}, item, { completed: !item.completed }));
    } catch (error) {
      wx.showToast({ title: errorText(error, "更新失败，请重试"), icon: "none" });
    } finally {
      this.todoSaving.delete(id);
    }
  },

  async deleteTodo(event) {
    const id = event.currentTarget.dataset.id;
    const confirmed = await new Promise(function (resolve) {
      wx.showModal({ title: "删除待办？", confirmText: "删除", confirmColor: "#c96050", success: function (result) { resolve(result.confirm); } });
    });
    if (!confirmed) return;
    try {
      await store.remove("todos", id);
      wx.showToast({ title: "已删除", icon: "success" });
    } catch (error) {
      wx.showToast({ title: errorText(error, "删除失败，请重试"), icon: "none" });
    }
  },

  onShareAppMessage() {
    return { title: "硕之的婴儿成长工作台", path: "/pages/home/index" };
  },
});
