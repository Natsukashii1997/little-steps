const store = require('../../lib/store');
const { getHeaderLayout } = require('../../lib/layout');
const validation = require('../../lib/validation');

const BIRTH = { id: 'birth-growth-fixed', date: '2026-08-04', weight: 2.4, height: 48, note: '出生记录', isBirth: true };
const today = () => validation.todayKey();
const id = () => `growth-${Date.now()}-${Math.random().toString(16).slice(2)}`;
const displayDate = (value) => {
  const [year, month, day] = String(value || '').split('-');
  return year && month && day ? `${year}年${Number(month)}月${Number(day)}日` : '未填写';
};
const errorText = (error, fallback) => error && (error.errMsg || error.message) || fallback;
function ageLabel() {
  const birth = new Date('2026-08-04T12:00:00'); const now = new Date();
  let months = (now.getFullYear() - birth.getFullYear()) * 12 + now.getMonth() - birth.getMonth();
  if (now.getDate() < birth.getDate()) months--;
  const anchor = new Date(birth.getFullYear(), birth.getMonth() + months, birth.getDate());
  const days = Math.max(0, Math.floor((now - anchor) / 86400000));
  return `${Math.max(0, months)}个月${days}天`;
}
function normalise(data) {
  const list = (data.growthRecords || []).filter((r) => r.date !== BIRTH.date).map((r) => ({ ...r, isBirth:false }));
  return [BIRTH, ...list].sort((a,b) => String(b.date).localeCompare(String(a.date))).map((r) => ({ ...r, displayDate: displayDate(r.date), weightText:r.weight === undefined ? '—' : Number(r.weight).toFixed(1), heightText:r.height === undefined ? '—' : Number(r.height).toFixed(1), noteText:r.note || '—' }));
}

Page({
  data: { headerHeight: getHeaderLayout().totalHeight, records: [], chartPoints: [], ageLabel: ageLabel(), today: today(), saving: false, editor: { open:false } },
  onLoad() { this.unsubscribe = store.subscribe(() => this.refresh()); this.refresh(); },
  onShow(){ this.refresh(); }, onUnload(){ if(this.unsubscribe) this.unsubscribe(); },
  onShareAppMessage(){ return { title:'硕之的成长曲线', path:'/pages/growth/index' }; },
  refresh() { const records = normalise(store.getData()); this.setData({ records, chartPoints:[...records].reverse(), today:today(), ageLabel:ageLabel() }, () => this.drawChart()); },
  onReady(){ this.drawChart(); },
  onNavigate(e){ const page = e.detail?.page || e.currentTarget.dataset.page; if(page) wx.reLaunch({ url:`/pages/${page}/index` }); },
  noop(){},
  openAdd(){ this.setData({ editor:{ open:true, id:'', isBirth:false, date:today(), height:'', weight:'', note:'' } }); },
  openEdit(e){ const row=this.data.records.find((r)=>r.id===e.currentTarget.dataset.id); if(!row)return; this.setData({ editor:{ open:true,id:row.id,isBirth:row.isBirth,date:row.date,height:row.height === undefined?'':String(row.height),weight:row.weight === undefined?'':String(row.weight),note:row.note||'' } }); },
  closeEditor(){ if(this.data.saving)return; this.setData({ editor:{open:false} }); },
  changeDate(e){ this.setData({'editor.date':e.detail.value}); }, changeHeight(e){this.setData({'editor.height':e.detail.value});}, changeWeight(e){this.setData({'editor.weight':e.detail.value});}, changeNote(e){this.setData({'editor.note':e.detail.value});},
  async saveRecord(){
    if(this.data.saving)return;
    const e=this.data.editor;
    const result=validation.validateGrowthRecord(e,store.getData().growthRecords,new Date());
    if(!result.ok)return wx.showToast({title:result.message,icon:'none'});
    const record={...result.value,id:e.id||id()};
    try{
      this.setData({saving:true});
      await store.upsert('growthRecords',record);
      this.setData({editor:{open:false}});
      wx.showToast({title:'已保存',icon:'success'});
    }catch(error){
      wx.showToast({title:errorText(error,'保存失败，请重试'),icon:'none'});
    }finally{
      this.setData({saving:false});
    }
  },
  async deleteRecord(){
    if(this.data.saving)return;
    const e=this.data.editor;
    if(!e.id||e.isBirth)return;
    const confirmed=await new Promise((resolve)=>wx.showModal({title:'删除成长数据？',content:'删除后不能恢复。',success:(result)=>resolve(result.confirm),fail:()=>resolve(false)}));
    if(!confirmed)return;
    try{
      this.setData({saving:true});
      await store.remove('growthRecords',e.id);
      this.setData({editor:{open:false}});
      wx.showToast({title:'已删除',icon:'success'});
    }catch(error){
      wx.showToast({title:errorText(error,'删除失败，请重试'),icon:'none'});
    }finally{
      this.setData({saving:false});
    }
  },
  drawChart(){ if(!this.data.chartPoints?.length)return; const points=this.data.chartPoints; wx.createSelectorQuery().select('#growthChart').fields({node:true,size:true}).exec((res)=>{const box=res[0];if(!box?.node)return; const canvas=box.node,ctx=canvas.getContext('2d'),dpr=wx.getSystemInfoSync().pixelRatio||1,w=box.width,h=box.height; canvas.width=w*dpr;canvas.height=h*dpr;ctx.scale(dpr,dpr);ctx.clearRect(0,0,w,h); const left=48,right=40,top=30,bottom=55,cw=w-left-right,ch=h-top-bottom;const pointX=(index,count)=>count===1?left+cw/2:left+(index*cw/(count-1));const drawLine=(arr,key,color,minPad)=>{const raw=arr.map(x=>Number(x[key])).filter(Number.isFinite);if(!raw.length)return; const min=Math.floor((Math.min(...raw)-minPad)*10)/10,max=Math.ceil((Math.max(...raw)+minPad)*10)/10;ctx.strokeStyle=color;ctx.lineWidth=2.5;ctx.beginPath();let used=0;arr.forEach((p,i)=>{if(!Number.isFinite(Number(p[key])))return;const x=pointX(i,arr.length),y=top+ch-(Number(p[key])-min)/(max-min||1)*ch;if(!used)ctx.moveTo(x,y);else ctx.lineTo(x,y);used++;});ctx.stroke();arr.forEach((p,i)=>{if(!Number.isFinite(Number(p[key])))return;const x=pointX(i,arr.length),y=top+ch-(Number(p[key])-min)/(max-min||1)*ch;ctx.fillStyle='#fffaf0';ctx.strokeStyle=color;ctx.lineWidth=2.5;ctx.beginPath();ctx.arc(x,y,5,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillStyle=color;ctx.font='11px sans-serif';ctx.textAlign='center';ctx.fillText(Number(p[key]).toFixed(1),x,y-11);});return {min,max};};ctx.strokeStyle='#c5b9a0';ctx.setLineDash([4,5]);ctx.lineWidth=1;for(let i=0;i<4;i++){const y=top+(ch*i/3);ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(w-right,y);ctx.stroke();}ctx.setLineDash([]);ctx.strokeStyle='#28251f';ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(left,top);ctx.lineTo(left,top+ch);ctx.lineTo(w-right,top+ch);ctx.stroke();drawLine(points,'height','#3178bc',3);drawLine(points,'weight','#58733d',.5);ctx.fillStyle='#3178bc';ctx.font='bold 12px sans-serif';ctx.textAlign='left';ctx.fillText('身高 cm',left,18);ctx.fillStyle='#58733d';ctx.textAlign='right';ctx.fillText('体重 kg',w-right,18);ctx.fillStyle='#564f45';ctx.font='10px sans-serif';ctx.textAlign='center';points.forEach((p,i)=>{const x=pointX(i,points.length);ctx.fillText(p.date.slice(5).replace('-','/'),x,h-18);});}); }
});
