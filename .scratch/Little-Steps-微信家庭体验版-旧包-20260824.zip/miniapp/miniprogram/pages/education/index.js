"use strict";

const store = require("../../lib/store");
const media = require("../../lib/media");
const { getHeaderLayout } = require("../../lib/layout");

const MUSIC_COVERS = [
  "/assets/education/lullaby-cover-v1.webp",
  "/assets/education/white-noise-cover-v1.webp",
  "/assets/education/nursery-cover-v1.webp",
];
const STORY_COVERS = [
  "/assets/education/caterpillar-cover-v1.webp",
  "/assets/education/goodnight-cover-v1.webp",
];

function durationLabel(seconds) {
  const total = Math.max(0, Number(seconds || 0));
  const minutes = Math.floor(total / 60);
  return String(minutes).padStart(2, "0") + ":" + String(Math.floor(total % 60)).padStart(2, "0");
}

function resolveCloudPath(path) {
  if (!path || String(path).indexOf("cloud://") !== 0 || !wx.cloud || !wx.cloud.getTempFileURL) {
    return Promise.resolve(path || "");
  }
  return new Promise(function (resolve, reject) {
    wx.cloud.getTempFileURL({
      fileList: [path],
      success: function (result) {
        const item = result && result.fileList && result.fileList[0];
        if (item && item.tempFileURL) resolve(item.tempFileURL);
        else reject(new Error("暂时无法读取这段音频"));
      },
      fail: reject,
    });
  });
}

Page({
  data: {
    headerHeight: getHeaderLayout().totalHeight,
    activeTab: "music",
    musicTracks: [],
    stories: [],
    previewStories: [],
    playingId: "",
    paused: false,
    currentSeconds: 0,
    totalSeconds: 0,
    uploading: false,
    saving: false,
    editor: { open: false, kind: "music" },
  },

  async onLoad() {
    this.unloaded = false;
    this.unsubscribe = store.subscribe(() => this.refresh());
    const app = getApp();
    try {
      if (app.globalData && app.globalData.ready) await app.globalData.ready;
      else await store.init();
    } catch (error) {
      // Local data remains available when cloud sync is offline.
    }
    this.refresh();
  },

  onShow() {
    this.refresh();
  },

  onUnload() {
    this.unloaded = true;
    if (this.unsubscribe) this.unsubscribe();
    this.destroyAudio(true);
  },

  onShareAppMessage() {
    return { title: "硕之的早期教育", path: "/pages/education/index" };
  },

  refresh() {
    const data = store.getData();
    const playingId = this.data.playingId;
    const paused = this.data.paused;
    const currentSeconds = this.data.currentSeconds;
    const totalSeconds = this.data.totalSeconds;
    const musicTracks = (data.musicTracks || []).map(function (item, index) {
      const active = item.id === playingId;
      return Object.assign({}, item, {
        coverSrc: item.coverId || MUSIC_COVERS[index % MUSIC_COVERS.length],
        durationText: durationLabel(active && totalSeconds ? totalSeconds : item.durationSeconds),
        currentText: durationLabel(active ? currentSeconds : 0),
        active: active,
        paused: active && paused,
        playable: Boolean(item.assetId),
      });
    });
    const stories = (data.stories || []).map(function (item, index) {
      return Object.assign({}, item, {
        coverSrc: item.coverId || STORY_COVERS[index % STORY_COVERS.length],
      });
    });
    this.setData({ musicTracks, stories, previewStories: stories.slice(0, 2) });
  },

  switchTab(event) {
    const activeTab = event.currentTarget.dataset.tab;
    if (activeTab === this.data.activeTab) return;
    this.setData({ activeTab });
  },

  openAddMusic() {
    this.setData({
      editor: {
        open: true,
        kind: "music",
        id: "",
        name: "",
        artist: "",
        description: "",
        durationSeconds: "",
        assetId: "",
        audioName: "",
        coverId: "",
        originalAssetId: "",
        originalCoverId: "",
        originalAudioName: "",
      },
    });
  },

  openAddStory() {
    this.setData({
      editor: {
        open: true,
        kind: "story",
        id: "",
        name: "",
        link: "",
        coverId: "",
        originalCoverId: "",
      },
    });
  },

  editMusic(event) {
    const item = this.data.musicTracks.find((record) => record.id === event.currentTarget.dataset.id);
    if (!item) return;
    this.setData({
      editor: {
        open: true,
        kind: "music",
        id: item.id,
        name: item.name || "",
        artist: item.artist || "",
        description: item.description || "",
        durationSeconds: item.durationSeconds ? String(item.durationSeconds) : "",
        assetId: item.assetId || "",
        audioName: item.audioName || "",
        coverId: item.coverId || "",
        originalAssetId: item.assetId || "",
        originalCoverId: item.coverId || "",
        originalAudioName: item.audioName || "",
      },
    });
  },

  editStory(event) {
    const item = this.data.stories.find((record) => record.id === event.currentTarget.dataset.id);
    if (!item) return;
    this.setData({
      editor: {
        open: true,
        kind: "story",
        id: item.id,
        name: item.name || "",
        link: item.link || "",
        coverId: item.coverId || "",
        originalCoverId: item.coverId || "",
      },
    });
  },

  async closeEditor() {
    if (this.data.uploading || this.data.saving) return;
    const editor = this.data.editor || {};
    const originalRefs = editor.kind === "music"
      ? [editor.originalAssetId, editor.originalCoverId]
      : [editor.originalCoverId];
    const currentRefs = editor.kind === "music"
      ? [editor.assetId, editor.coverId]
      : [editor.coverId];
    await media.discardDraft({ originalRefs, currentRefs });
    this.setData({ editor: { open: false, kind: this.data.editor.kind || "music" } });
  },

  noop() {},

  inputName(event) { this.setData({ "editor.name": event.detail.value }); },
  inputArtist(event) { this.setData({ "editor.artist": event.detail.value }); },
  inputDescription(event) { this.setData({ "editor.description": event.detail.value }); },
  inputDuration(event) { this.setData({ "editor.durationSeconds": event.detail.value }); },
  inputLink(event) { this.setData({ "editor.link": event.detail.value }); },

  async chooseCover() {
    if (this.data.uploading || this.data.saving) return;
    try {
      const files = await media.chooseImage({ count: 1 });
      if (!files[0]) return;
      this.setData({ uploading: true });
      wx.showLoading({ title: "保存图片中" });
      const result = await media.uploadImage(files[0]);
      const coverId = media.mediaPath(result);
      if (!coverId) throw new Error("图片保存失败");
      const previousDraft = this.data.editor.coverId;
      this.setData({ "editor.coverId": coverId });
      await media.discardDraft({
        originalRefs: [this.data.editor.originalCoverId],
        currentRefs: [previousDraft],
      });
      wx.showToast({ title: "图片已选择", icon: "success" });
    } catch (error) {
      if (error && String(error.errMsg || "").indexOf("cancel") !== -1) return;
      wx.showToast({ title: error.message || "图片保存失败", icon: "none" });
    } finally {
      wx.hideLoading();
      this.setData({ uploading: false });
    }
  },

  async chooseTrackAudio() {
    if (this.data.uploading || this.data.saving) return;
    try {
      const files = await media.chooseAudio({ count: 1 });
      if (!files[0]) return;
      this.setData({ uploading: true });
      wx.showLoading({ title: "保存音频中" });
      const result = await media.uploadAudio(files[0]);
      const assetId = media.mediaPath(result);
      if (!assetId) throw new Error("音频保存失败");
      const previousDraft = this.data.editor.assetId;
      this.setData({
        "editor.assetId": assetId,
        "editor.audioName": result.name || files[0].name || "已上传音频",
      });
      await media.discardDraft({
        originalRefs: [this.data.editor.originalAssetId],
        currentRefs: [previousDraft],
      });
      wx.showToast({ title: "音频已选择", icon: "success" });
    } catch (error) {
      if (error && String(error.errMsg || "").indexOf("cancel") !== -1) return;
      wx.showToast({ title: error.message || "音频保存失败", icon: "none" });
    } finally {
      wx.hideLoading();
      this.setData({ uploading: false });
    }
  },

  async saveEditor() {
    if (this.data.uploading || this.data.saving) return;
    const editor = this.data.editor;
    const name = String(editor.name || "").trim();
    if (!name) return wx.showToast({ title: "请填写名称", icon: "none" });

    try {
      if (editor.kind === "music") {
        const durationSeconds = Number(editor.durationSeconds || 0);
        if (durationSeconds < 0 || !Number.isFinite(durationSeconds)) {
          return wx.showToast({ title: "时长填写不正确", icon: "none" });
        }
        this.setData({ saving: true });
        await media.commitChange({
          originalRefs: [editor.originalAssetId, editor.originalCoverId],
          currentRefs: [editor.assetId, editor.coverId],
          persist: function () {
            return store.upsert("musicTracks", {
              id: editor.id || undefined,
              name: name,
              artist: String(editor.artist || "").trim(),
              description: String(editor.description || "").trim(),
              durationSeconds: durationSeconds,
              assetId: editor.assetId || "",
              audioName: editor.audioName || "",
              coverId: editor.coverId || "",
            });
          },
        });
      } else {
        const link = String(editor.link || "").trim();
        if (!/^https?:\/\//i.test(link)) {
          return wx.showToast({ title: "请填写 http 或 https 绘本链接", icon: "none" });
        }
        this.setData({ saving: true });
        await media.commitChange({
          originalRefs: [editor.originalCoverId],
          currentRefs: [editor.coverId],
          persist: function () {
            return store.upsert("stories", {
              id: editor.id || undefined,
              name: name,
              link: link,
              coverId: editor.coverId || "",
            });
          },
        });
      }
      this.setData({ editor: { open: false, kind: editor.kind || "music" } });
      this.refresh();
      wx.showToast({ title: "已保存", icon: "success" });
    } catch (error) {
      if (editor.kind === "music") {
        this.setData({
          "editor.assetId": editor.originalAssetId || "",
          "editor.coverId": editor.originalCoverId || "",
          "editor.audioName": editor.originalAudioName || "",
        });
      } else {
        this.setData({ "editor.coverId": editor.originalCoverId || "" });
      }
      wx.showToast({ title: error.message || "保存失败，请重试", icon: "none" });
    } finally {
      this.setData({ saving: false });
    }
  },

  deleteEditor() {
    if (this.data.uploading || this.data.saving) return;
    const editor = this.data.editor;
    if (!editor.id) return;
    const collection = editor.kind === "music" ? "musicTracks" : "stories";
    const label = editor.kind === "music" ? "这首音乐" : "这本绘本";
    wx.showModal({
      title: "确认删除？",
      content: "删除" + label + "后无法恢复。",
      confirmColor: "#c96050",
      success: async (result) => {
        if (!result.confirm) return;
        if (editor.kind === "music" && editor.id === this.data.playingId) this.destroyAudio();
        try {
          this.setData({ saving: true });
          const refs = editor.kind === "music" ? [editor.assetId, editor.coverId] : [editor.coverId];
          await media.removeWithMedia({
            refs,
            persist: function () { return store.remove(collection, editor.id); },
          });
          this.setData({ editor: { open: false, kind: editor.kind || "music" } });
          this.refresh();
          wx.showToast({ title: "已删除", icon: "success" });
        } catch (error) {
          wx.showToast({ title: error.message || "删除失败，请重试", icon: "none" });
        } finally {
          this.setData({ saving: false });
        }
      },
    });
  },

  copyStoryLink(event) {
    const story = this.data.stories.find((item) => item.id === event.currentTarget.dataset.id);
    if (!story || !story.link) return;
    wx.setClipboardData({
      data: story.link,
      success: function () {
        wx.showToast({ title: "链接已复制，请在浏览器打开", icon: "none", duration: 2200 });
      },
    });
  },

  async toggleTrack(event) {
    const id = event.currentTarget.dataset.id;
    const track = this.data.musicTracks.find((item) => item.id === id);
    if (!track) return;
    if (!track.assetId) {
      wx.showToast({ title: "请先点击音乐卡片上传音频", icon: "none", duration: 2200 });
      return;
    }

    if (this.audio && this.data.playingId === id) {
      if (this.data.paused) this.audio.play();
      else this.audio.pause();
      return;
    }

    this.destroyAudio();
    const requestToken = {};
    this.audioRequestToken = requestToken;
    wx.showLoading({ title: "准备播放" });
    try {
      const source = await resolveCloudPath(track.assetId);
      if (this.unloaded || this.audioRequestToken !== requestToken) return;
      if (!source) throw new Error("未找到音频文件");
      const audio = wx.createInnerAudioContext();
      this.audio = audio;
      audio.obeyMuteSwitch = false;
      let shouldAutoPlay = true;
      audio.onCanplay(() => {
        if (this.audio === audio && shouldAutoPlay) {
          shouldAutoPlay = false;
          audio.play();
        }
      });
      audio.onPlay(() => {
        wx.hideLoading();
        this.setData({ playingId: id, paused: false });
        this.refresh();
      });
      audio.onPause(() => {
        if (this.audio !== audio) return;
        this.setData({ paused: true });
        this.refresh();
      });
      audio.onTimeUpdate(() => {
        if (this.audio !== audio) return;
        this.setData({
          currentSeconds: Number(audio.currentTime || 0),
          totalSeconds: Number(audio.duration || track.durationSeconds || 0),
        });
        this.refresh();
      });
      audio.onEnded(() => {
        if (this.audio === audio) this.destroyAudio();
      });
      audio.onError(() => {
        if (this.audio !== audio) return;
        wx.hideLoading();
        this.destroyAudio();
        wx.showToast({ title: "音频无法播放，请重新上传", icon: "none" });
      });
      audio.src = source;
    } catch (error) {
      if (this.unloaded || this.audioRequestToken !== requestToken) return;
      wx.hideLoading();
      wx.showToast({ title: error.message || "音频无法播放", icon: "none" });
    }
  },

  seekTrack(event) {
    if (!this.audio || event.currentTarget.dataset.id !== this.data.playingId) return;
    this.audio.seek(Number(event.detail.value || 0));
  },

  destroyAudio(silent) {
    this.audioRequestToken = null;
    if (this.audio) {
      try { this.audio.stop(); } catch (error) { /* no-op */ }
      try { this.audio.destroy(); } catch (error) { /* no-op */ }
      this.audio = null;
    }
    if (!silent && this.data && this.data.playingId) {
      this.setData({ playingId: "", paused: false, currentSeconds: 0, totalSeconds: 0 });
      this.refresh();
    }
  },
});
