"use strict";

const store = require("../../lib/store");
const media = require("../../lib/media");
const { getHeaderLayout } = require("../../lib/layout");

const DEFAULT_CARDS = [
  { key: "apple", english: "Apple", chinese: "苹果" },
  { key: "dog", english: "Dog", chinese: "小狗" },
  { key: "moon", english: "Moon", chinese: "月亮" },
  { key: "ball", english: "Ball", chinese: "球" },
  { key: "cat", english: "Cat", chinese: "小猫" },
  { key: "sun", english: "Sun", chinese: "太阳" },
  { key: "fish", english: "Fish", chinese: "鱼" },
  { key: "bird", english: "Bird", chinese: "小鸟" },
  { key: "flower", english: "Flower", chinese: "花" },
  { key: "car", english: "Car", chinese: "汽车" },
  { key: "star", english: "Star", chinese: "星星" },
  { key: "bear", english: "Bear", chinese: "小熊" },
  { key: "book", english: "Book", chinese: "图书" },
  { key: "duck", english: "Duck", chinese: "小鸭" },
  { key: "tree", english: "Tree", chinese: "大树" },
];

const ARTWORK_OPTIONS = DEFAULT_CARDS.map(function (item) {
  return { key: item.key, label: item.english + " · " + item.chinese };
});

async function ensureDefaultCards() {
  const snapshot = store.getData();
  if (Number(snapshot.studySeedVersion || 0) >= 1) return;
  const current = snapshot.learningItems || [];
  const missing = [];
  DEFAULT_CARDS.forEach(function (card) {
    if (!current.some((item) => item.kind === "english" && item.artworkKey === card.key)) {
      missing.push({
        id: "learn-english-" + card.key,
        kind: "english",
        term: card.english,
        translation: card.chinese,
        artworkKey: card.key,
        imageId: "",
      });
    }
    if (!current.some((item) => item.kind === "chinese" && item.artworkKey === card.key)) {
      missing.push({
        id: "learn-chinese-" + card.key,
        kind: "chinese",
        term: card.chinese,
        translation: card.english,
        artworkKey: card.key,
        imageId: "",
      });
    }
  });
  await store.mutate(function (next) {
    if (missing.length) next.learningItems = (next.learningItems || []).concat(missing);
    next.studySeedVersion = 1;
    return next;
  });
}

Page({
  data: {
    headerHeight: getHeaderLayout().totalHeight,
    activeTab: "english",
    items: [],
    pageIndex: 0,
    pageCount: 1,
    totalCount: 0,
    artworkOptions: ARTWORK_OPTIONS,
    uploading: false,
    saving: false,
    editor: { open: false, kind: "english", artworkIndex: 0 },
  },

  async onLoad() {
    this.unsubscribe = store.subscribe(() => this.refresh());
    const app = getApp();
    try {
      if (app.globalData && app.globalData.ready) await app.globalData.ready;
      else await store.init();
    } catch (error) {
      // Continue with the local snapshot when family sync is temporarily unavailable.
    }
    try {
      await ensureDefaultCards();
    } catch (error) {
      // The existing cards remain usable if the one-time local seed cannot be written.
    }
    this.refresh();
  },

  onShow() {
    this.refresh();
  },

  onUnload() {
    if (this.unsubscribe) this.unsubscribe();
  },

  onShareAppMessage() {
    return { title: "硕之的学习记录", path: "/pages/study/index" };
  },

  refresh() {
    const all = (store.getData().learningItems || []).filter((item) => item.kind === this.data.activeTab);
    const pageCount = Math.max(1, Math.ceil(all.length / 15));
    const pageIndex = Math.min(this.data.pageIndex, pageCount - 1);
    const items = all.slice(pageIndex * 15, pageIndex * 15 + 15).map(function (item, index) {
      const key = ARTWORK_OPTIONS.some((option) => option.key === item.artworkKey) ? item.artworkKey : "bear";
      return Object.assign({}, item, {
        imageSrc: item.imageId || "/assets/study/" + key + ".webp",
        tone: index % 6,
      });
    });
    this.setData({ items, pageCount, pageIndex, totalCount: all.length });
  },

  switchTab(event) {
    const activeTab = event.currentTarget.dataset.tab;
    if (activeTab === this.data.activeTab) return;
    this.setData({ activeTab, pageIndex: 0 }, () => this.refresh());
  },

  previousPage() {
    if (this.data.pageIndex <= 0) return;
    this.setData({ pageIndex: this.data.pageIndex - 1 }, () => this.refresh());
  },

  nextPage() {
    if (this.data.pageIndex >= this.data.pageCount - 1) return;
    this.setData({ pageIndex: this.data.pageIndex + 1 }, () => this.refresh());
  },

  openAdd() {
    const kind = this.data.activeTab;
    this.setData({
      editor: {
        open: true,
        kind: kind,
        id: "",
        term: "",
        translation: "",
        artworkKey: ARTWORK_OPTIONS[0].key,
        artworkIndex: 0,
        imageId: "",
        originalImageId: "",
      },
    });
  },

  editItem(event) {
    const item = this.data.items.find((record) => record.id === event.currentTarget.dataset.id);
    if (!item) return;
    const artworkIndex = Math.max(0, ARTWORK_OPTIONS.findIndex((option) => option.key === item.artworkKey));
    this.setData({
      editor: {
        open: true,
        kind: item.kind || this.data.activeTab,
        id: item.id,
        term: item.term || "",
        translation: item.translation || "",
        artworkKey: ARTWORK_OPTIONS[artworkIndex].key,
        artworkIndex: artworkIndex,
        imageId: item.imageId || "",
        originalImageId: item.imageId || "",
      },
    });
  },

  async closeEditor() {
    if (this.data.uploading || this.data.saving) return;
    const editor = this.data.editor || {};
    await media.discardDraft({
      originalRefs: [editor.originalImageId],
      currentRefs: [editor.imageId],
    });
    this.setData({ editor: { open: false, kind: this.data.activeTab, artworkIndex: 0 } });
  },

  noop() {},
  inputTerm(event) { this.setData({ "editor.term": event.detail.value }); },
  inputTranslation(event) { this.setData({ "editor.translation": event.detail.value }); },

  chooseEditorKind(event) {
    const kind = event.currentTarget.dataset.kind;
    this.setData({ "editor.kind": kind });
  },

  changeArtwork(event) {
    const artworkIndex = Number(event.detail.value || 0);
    const option = ARTWORK_OPTIONS[artworkIndex] || ARTWORK_OPTIONS[0];
    this.setData({ "editor.artworkIndex": artworkIndex, "editor.artworkKey": option.key });
  },

  async chooseImage() {
    if (this.data.uploading || this.data.saving) return;
    try {
      const files = await media.chooseImage({ count: 1 });
      if (!files[0]) return;
      this.setData({ uploading: true });
      wx.showLoading({ title: "保存图片中" });
      const result = await media.uploadImage(files[0]);
      const imageId = media.mediaPath(result);
      if (!imageId) throw new Error("图片保存失败");
      const previousDraft = this.data.editor.imageId;
      this.setData({ "editor.imageId": imageId });
      await media.discardDraft({
        originalRefs: [this.data.editor.originalImageId],
        currentRefs: [previousDraft],
      });
      wx.showToast({ title: "图片已选择", icon: "success" });
    } catch (error) {
      if (error && String(error.errMsg || "").indexOf("cancel") !== -1) return;
      wx.showToast({ title: error.message || "图片保存失败", icon: "none" });
    } finally {
      wx.hideLoading();
      this.setData({ uploading: false });
    }
  },

  async saveEditor() {
    if (this.data.uploading || this.data.saving) return;
    const editor = this.data.editor;
    const term = String(editor.term || "").trim();
    const translation = String(editor.translation || "").trim();
    if (!term || !translation) {
      return wx.showToast({ title: "请填写词语和释义", icon: "none" });
    }
    const recordId = editor.id || "learning-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8);
    try {
      this.setData({ saving: true });
      const next = await media.commitChange({
        originalRefs: [editor.originalImageId],
        currentRefs: [editor.imageId],
        persist: function () {
          return store.upsert("learningItems", {
            id: recordId,
            kind: editor.kind,
            term: term,
            translation: translation,
            artworkKey: editor.artworkKey || "bear",
            imageId: editor.imageId || "",
          });
        },
      });
      const activeTab = editor.kind;
      const tabItems = (next.learningItems || []).filter((item) => item.kind === activeTab);
      const savedIndex = Math.max(0, tabItems.findIndex((item) => item.id === recordId));
      const pageIndex = Math.floor(savedIndex / 15);
      this.setData({ editor: { open: false, kind: activeTab, artworkIndex: 0 }, activeTab, pageIndex }, () => this.refresh());
      wx.showToast({ title: "已保存", icon: "success" });
    } catch (error) {
      this.setData({ "editor.imageId": editor.originalImageId || "" });
      wx.showToast({ title: error.message || "保存失败，请重试", icon: "none" });
    } finally {
      this.setData({ saving: false });
    }
  },

  deleteEditor() {
    if (this.data.uploading || this.data.saving) return;
    const editor = this.data.editor;
    if (!editor.id) return;
    wx.showModal({
      title: "删除这张学习卡？",
      content: "删除后无法恢复。",
      confirmColor: "#c96050",
      success: async (result) => {
        if (!result.confirm) return;
        try {
          this.setData({ saving: true });
          await media.removeWithMedia({
            refs: [editor.imageId],
            persist: function () { return store.remove("learningItems", editor.id); },
          });
          this.setData({ editor: { open: false, kind: this.data.activeTab, artworkIndex: 0 } });
          this.refresh();
          wx.showToast({ title: "已删除", icon: "success" });
        } catch (error) {
          wx.showToast({ title: error.message || "删除失败，请重试", icon: "none" });
        } finally {
          this.setData({ saving: false });
        }
      },
    });
  },
});
