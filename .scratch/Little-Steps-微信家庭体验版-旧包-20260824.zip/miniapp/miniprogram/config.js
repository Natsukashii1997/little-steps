module.exports = {
  envId: "",
  useCloud: false,
  familyMaxMembers: 5,
  schemaVersion: 2,
};
