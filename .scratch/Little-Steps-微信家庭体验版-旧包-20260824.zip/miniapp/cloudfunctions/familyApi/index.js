'use strict';

// The only database gateway used by the family mini program.  Keep the data
// model intentionally small: one family document and one versioned snapshot.
const crypto = require('node:crypto');
const cloud = require('wx-server-sdk');

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });

const MAX_MEMBERS = 5;
const MAX_SNAPSHOT_BYTES = 850000;
const MAX_BACKUPS = 30;
const BACKUP_QUERY_LIMIT = 100;
const CAPACITY_WARNING_RATIO = 0.8;
const EXPORT_FORMAT = 'baby-care-family-export-v1';

function createFamilyApi(options) {
  const db = options.database;
  const _ = db.command;
  const getWXContext = options.getWXContext;
  const logger = options.logger || console;
  const now = options.now || (() => new Date().toISOString());
  const uniqueId = options.uniqueId || (() => crypto.randomBytes(8).toString('hex'));

function response(ok, payload) {
  return { ok, ...payload };
}

function failure(code, message) {
  return response(false, { error: { code, message } });
}

function normalizeInviteCode(value) {
  return String(value || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
}

function inviteCode() {
  // Unambiguous six-character code: easy to share in a family chat.
  const alphabet = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  let code = '';
  for (let index = 0; index < 6; index += 1) {
    code += alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  return code;
}

function publicFamily(family, openId) {
  const memberOpenIds = Array.isArray(family.memberOpenIds) ? family.memberOpenIds : [];
  return {
    familyId: family._id,
    owner: family.ownerOpenId === openId,
    memberCount: memberOpenIds.length,
    maxMembers: family.maxMembers || MAX_MEMBERS,
    // Only the owner can reveal the invite code.  Members never receive it.
    inviteCode: family.ownerOpenId === openId ? family.inviteCode : undefined,
  };
}

function asPlainSnapshot(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('INVALID_SNAPSHOT');
  }

  const json = JSON.stringify(value);
  if (!json || Buffer.byteLength(json, 'utf8') > MAX_SNAPSHOT_BYTES) {
    throw new Error('SNAPSHOT_TOO_LARGE');
  }

  return JSON.parse(json);
}

function snapshotDetails(value) {
  const data = asPlainSnapshot(value);
  const json = JSON.stringify(data);
  const byteLength = Buffer.byteLength(json, 'utf8');
  return {
    data,
    byteLength,
    checksumSha256: crypto.createHash('sha256').update(json).digest('hex'),
  };
}

function capacityStatus(byteLength) {
  const snapshotBytes = Number.isInteger(byteLength) && byteLength >= 0 ? byteLength : 0;
  return {
    storageFormat: 'legacy-snapshot-v1',
    snapshotBytes,
    snapshotLimitBytes: MAX_SNAPSHOT_BYTES,
    usageRatio: Number((snapshotBytes / MAX_SNAPSHOT_BYTES).toFixed(4)),
    warning: snapshotBytes >= MAX_SNAPSHOT_BYTES * CAPACITY_WARNING_RATIO,
    partitionMigrationAvailable: false,
  };
}

function backupId(familyId, version, suffix = '') {
  const paddedVersion = String(version).padStart(12, '0');
  return `${familyId}__v${paddedVersion}${suffix ? `__${suffix}` : ''}`;
}

function backupDocument(familyId, version, details, reason, openId) {
  return {
    familyId,
    version,
    data: details.data,
    byteLength: details.byteLength,
    checksumSha256: details.checksumSha256,
    reason,
    createdAt: db.serverDate(),
    createdBy: openId,
  };
}

async function pruneBackups(familyId) {
  try {
    const result = await db.collection('family_backups')
      .where({ familyId })
      .limit(BACKUP_QUERY_LIMIT)
      .get();
    const stale = (result.data || [])
      .slice()
      .sort((left, right) => {
        const byVersion = (Number(right.version) || 0) - (Number(left.version) || 0);
        if (byVersion) return byVersion;
        return String(right._id || '').localeCompare(String(left._id || ''));
      })
      .slice(MAX_BACKUPS);
    await Promise.all(stale.map((item) => db.collection('family_backups').doc(item._id).remove()));
  } catch (error) {
    // A cleanup failure must never turn an already committed save into a false
    // failure.  The next successful write retries the bounded cleanup.
    logger.error('family backup cleanup failed', error);
  }
}

function publicBackup(item) {
  return {
    backupId: item._id,
    version: item.version,
    byteLength: item.byteLength,
    checksumSha256: item.checksumSha256,
    reason: item.reason,
    createdAt: item.createdAt || null,
  };
}

async function findFamilyFor(openId) {
  const result = await db.collection('families')
    .where({ memberOpenIds: _.in([openId]) })
    .limit(1)
    .get();
  return result.data[0] || null;
}

async function getOwnedFamily(familyId, openId) {
  if (!familyId || typeof familyId !== 'string') {
    return null;
  }
  try {
    const result = await db.collection('families').doc(familyId).get();
    const family = result.data;
    return Array.isArray(family.memberOpenIds) && family.memberOpenIds.includes(openId)
      ? family
      : null;
  } catch (_) {
    return null;
  }
}

async function ensureSnapshot(familyId, openId) {
  try {
    const result = await db.collection('family_snapshots').doc(familyId).get();
    if (result.data) return result.data;
  } catch (_) {
    // The first family load creates the empty snapshot below.
  }
  await db.collection('family_snapshots').doc(familyId).set({
    data: {
      familyId,
      data: {},
      version: 0,
      updatedAt: db.serverDate(),
      updatedBy: openId,
    },
  });
  return {
    _id: familyId,
    familyId,
    data: {},
    version: 0,
    updatedBy: openId,
  };
}

async function bootstrap(openId) {
  const family = await findFamilyFor(openId);
  return response(true, {
    openId,
    joined: Boolean(family),
    family: family ? publicFamily(family, openId) : null,
  });
}

async function createFamily(openId) {
  const existing = await findFamilyFor(openId);
  if (existing) {
    return response(true, {
      openId,
      created: false,
      family: publicFamily(existing, openId),
    });
  }

  // Retry a few times in the extremely unlikely event of a code collision.
  for (let attempt = 0; attempt < 5; attempt += 1) {
    const code = inviteCode();
    const collision = await db.collection('families').where({ inviteCode: code }).limit(1).get();
    if (collision.data.length) continue;

    const created = await db.collection('families').add({
      data: {
        ownerOpenId: openId,
        memberOpenIds: [openId],
        inviteCode: code,
        maxMembers: MAX_MEMBERS,
        createdAt: db.serverDate(),
        updatedAt: db.serverDate(),
      },
    });
    await db.collection('family_snapshots').doc(created._id).set({
      data: {
        familyId: created._id,
        data: {},
        version: 0,
        updatedAt: db.serverDate(),
        updatedBy: openId,
      },
    });
    return response(true, {
      openId,
      created: true,
      family: {
        familyId: created._id,
        owner: true,
        memberCount: 1,
        maxMembers: MAX_MEMBERS,
        inviteCode: code,
      },
    });
  }
  return failure('INVITE_CODE_RETRY_EXHAUSTED', '邀请码生成失败，请重试。');
}

async function joinFamily(openId, event) {
  const code = normalizeInviteCode(event.inviteCode);
  if (code.length !== 6) {
    return failure('INVALID_INVITE_CODE', '请输入六位家庭邀请码。');
  }

  const current = await findFamilyFor(openId);
  if (current) {
    return failure('ALREADY_IN_FAMILY', '当前微信已加入一个家庭工作台。');
  }

  const found = await db.collection('families').where({ inviteCode: code }).limit(1).get();
  const family = found.data[0];
  if (!family) return failure('INVITE_CODE_NOT_FOUND', '邀请码无效或已失效。');

  try {
    const joined = await db.runTransaction(async (transaction) => {
      const fresh = await transaction.collection('families').doc(family._id).get();
      const members = Array.isArray(fresh.data.memberOpenIds) ? fresh.data.memberOpenIds : [];
      if (members.includes(openId)) return { status: 'already', family: fresh.data };
      if (members.length >= (fresh.data.maxMembers || MAX_MEMBERS)) return { status: 'full' };
      const nextMembers = [...members, openId];
      await transaction.collection('families').doc(family._id).update({
        data: { memberOpenIds: nextMembers, updatedAt: db.serverDate() },
      });
      return { status: 'joined', family: { ...fresh.data, memberOpenIds: nextMembers } };
    });

    if (joined.status === 'full') return failure('FAMILY_FULL', '此家庭已达到 5 人上限。');
    return response(true, {
      openId,
      joined: true,
      family: publicFamily(joined.family, openId),
    });
  } catch (error) {
    console.error('joinFamily failed', error);
    return failure('JOIN_FAILED', '加入家庭失败，请稍后重试。');
  }
}

async function load(openId, event) {
  const family = await getOwnedFamily(event.familyId, openId);
  if (!family) return failure('FORBIDDEN', '无权读取此家庭数据。');
  const snapshot = await ensureSnapshot(family._id, openId);
  const details = snapshotDetails(snapshot.data || {});
  return response(true, {
    openId,
    family: publicFamily(family, openId),
    snapshot: {
      data: details.data,
      version: Number.isInteger(snapshot.version) ? snapshot.version : 0,
      updatedAt: snapshot.updatedAt || null,
      updatedBy: snapshot.updatedBy || null,
      capacity: capacityStatus(details.byteLength),
    },
  });
}

async function save(openId, event) {
  const family = await getOwnedFamily(event.familyId, openId);
  if (!family) return failure('FORBIDDEN', '无权保存此家庭数据。');
  if (!Number.isInteger(event.expectedVersion) || event.expectedVersion < 0) {
    return failure('INVALID_VERSION', '保存版本无效，请重新加载后再试。');
  }

  let details;
  try {
    details = snapshotDetails(event.data);
  } catch (error) {
    return error.message === 'SNAPSHOT_TOO_LARGE'
      ? failure('SNAPSHOT_TOO_LARGE', '家庭记录过大，请先删除不需要的内容或媒体。')
      : failure('INVALID_SNAPSHOT', '家庭记录格式无效。');
  }

  await ensureSnapshot(family._id, openId);
  const transactionResult = await db.runTransaction(async (transaction) => {
    const current = await transaction.collection('family_snapshots').doc(family._id).get();
    const currentVersion = Number.isInteger(current.data.version) ? current.data.version : 0;
    if (currentVersion !== event.expectedVersion) return { conflict: true, currentVersion };
    const nextVersion = currentVersion + 1;
    await transaction.collection('family_backups').doc(backupId(family._id, nextVersion)).set({
      data: backupDocument(family._id, nextVersion, details, 'save', openId),
    });
    await transaction.collection('family_snapshots').doc(family._id).update({
      data: {
        data: details.data,
        version: nextVersion,
        updatedAt: db.serverDate(),
        updatedBy: openId,
      },
    });
    return { conflict: false, version: nextVersion };
  });
  if (transactionResult.conflict) {
    return failure('VERSION_CONFLICT', '家人刚刚保存过新数据，请重新加载后再保存。');
  }
  await pruneBackups(family._id);
  return response(true, {
    saved: true,
    version: transactionResult.version,
    updatedBy: openId,
    capacity: capacityStatus(details.byteLength),
  });
}

async function listBackups(openId, event) {
  const family = await getOwnedFamily(event.familyId, openId);
  if (!family) return failure('FORBIDDEN', '无权查看此家庭备份。');
  const requestedLimit = Number.isInteger(event.limit) ? event.limit : MAX_BACKUPS;
  const limit = Math.max(1, Math.min(requestedLimit, MAX_BACKUPS));
  const result = await db.collection('family_backups')
    .where({ familyId: family._id })
    .limit(BACKUP_QUERY_LIMIT)
    .get();
  const backups = (result.data || [])
    .filter((item) => Number.isInteger(item.version) && item.version >= 0)
    .sort((left, right) => {
      const byVersion = right.version - left.version;
      if (byVersion) return byVersion;
      return String(right._id || '').localeCompare(String(left._id || ''));
    })
    .slice(0, limit)
    .map(publicBackup);
  return response(true, { backups, retentionLimit: MAX_BACKUPS });
}

async function exportFamily(openId, event) {
  const family = await getOwnedFamily(event.familyId, openId);
  if (!family) return failure('FORBIDDEN', '无权导出此家庭数据。');
  const snapshot = await ensureSnapshot(family._id, openId);
  const details = snapshotDetails(snapshot.data || {});
  const version = Number.isInteger(snapshot.version) ? snapshot.version : 0;
  return response(true, {
    export: {
      format: EXPORT_FORMAT,
      exportedAt: now(),
      family: {
        familyId: family._id,
        memberCount: Array.isArray(family.memberOpenIds) ? family.memberOpenIds.length : 0,
        maxMembers: family.maxMembers || MAX_MEMBERS,
      },
      snapshot: {
        data: details.data,
        version,
        updatedAt: snapshot.updatedAt || null,
        checksumSha256: details.checksumSha256,
        byteLength: details.byteLength,
      },
    },
    capacity: capacityStatus(details.byteLength),
  });
}

async function restoreBackup(openId, event) {
  const family = await getOwnedFamily(event.familyId, openId);
  if (!family) return failure('FORBIDDEN', '无权恢复此家庭备份。');
  if (family.ownerOpenId !== openId) {
    return failure('OWNER_REQUIRED', '只有家庭创建者可以恢复备份。');
  }
  if (!Number.isInteger(event.expectedVersion) || event.expectedVersion < 0) {
    return failure('INVALID_VERSION', '恢复版本无效，请重新加载后再试。');
  }
  if (!event.backupId || typeof event.backupId !== 'string') {
    return failure('INVALID_BACKUP', '请选择有效的家庭备份。');
  }

  await ensureSnapshot(family._id, openId);
  const preRestoreId = backupId(
    family._id,
    event.expectedVersion,
    `pre_restore_${uniqueId()}`,
  );
  const transactionResult = await db.runTransaction(async (transaction) => {
    const current = await transaction.collection('family_snapshots').doc(family._id).get();
    const currentVersion = Number.isInteger(current.data.version) ? current.data.version : -1;
    if (currentVersion !== event.expectedVersion) return { conflict: true, currentVersion };

    let storedBackup;
    try {
      storedBackup = await transaction.collection('family_backups').doc(event.backupId).get();
    } catch (_) {
      return { missing: true };
    }
    const candidate = storedBackup.data;
    if (!candidate || candidate.familyId !== family._id
      || !Number.isInteger(candidate.version) || candidate.version < 0) {
      return { invalid: true };
    }

    let targetDetails;
    let currentDetails;
    try {
      targetDetails = snapshotDetails(candidate.data);
      currentDetails = snapshotDetails(current.data.data || {});
    } catch (error) {
      if (error.message === 'SNAPSHOT_TOO_LARGE') return { tooLarge: true };
      return { invalid: true };
    }
    if (candidate.byteLength !== targetDetails.byteLength
      || candidate.checksumSha256 !== targetDetails.checksumSha256) {
      return { integrityFailure: true };
    }

    const nextVersion = currentVersion + 1;
    await transaction.collection('family_backups').doc(preRestoreId).set({
      data: backupDocument(family._id, currentVersion, currentDetails, 'pre_restore', openId),
    });
    await transaction.collection('family_backups').doc(backupId(family._id, nextVersion)).set({
      data: backupDocument(family._id, nextVersion, targetDetails, 'restore', openId),
    });
    await transaction.collection('family_snapshots').doc(family._id).update({
      data: {
        data: targetDetails.data,
        version: nextVersion,
        updatedAt: db.serverDate(),
        updatedBy: openId,
      },
    });
    return {
      conflict: false,
      version: nextVersion,
      restoredFromVersion: candidate.version,
      byteLength: targetDetails.byteLength,
    };
  });

  if (transactionResult.conflict) {
    return failure('VERSION_CONFLICT', '家人刚刚保存过新数据，请重新加载后再恢复。');
  }
  if (transactionResult.missing) return failure('BACKUP_NOT_FOUND', '备份不存在或已超过保留期。');
  if (transactionResult.tooLarge) return failure('BACKUP_TOO_LARGE', '备份超过当前版本可恢复的容量上限。');
  if (transactionResult.integrityFailure) return failure('BACKUP_INTEGRITY_FAILED', '备份校验失败，未更改当前数据。');
  if (transactionResult.invalid) return failure('INVALID_BACKUP', '备份格式或版本无效。');

  await pruneBackups(family._id);
  return response(true, {
    restored: true,
    version: transactionResult.version,
    restoredFromVersion: transactionResult.restoredFromVersion,
    capacity: capacityStatus(transactionResult.byteLength),
  });
}

async function getStatus(openId, event) {
  const family = event.familyId
    ? await getOwnedFamily(event.familyId, openId)
    : await findFamilyFor(openId);
  if (!family) return response(true, { openId, joined: false, family: null });
  return response(true, {
    openId,
    joined: true,
    family: publicFamily(family, openId),
  });
}

async function main(event = {}) {
  const { OPENID } = getWXContext();
  if (!OPENID) return failure('UNAUTHENTICATED', '未获取到微信用户身份，请重新进入小程序。');

  try {
    switch (event.action) {
      case 'bootstrap': return await bootstrap(OPENID);
      case 'createFamily': return await createFamily(OPENID);
      case 'join': return await joinFamily(OPENID, event);
      case 'load': return await load(OPENID, event);
      case 'save': return await save(OPENID, event);
      case 'getStatus': return await getStatus(OPENID, event);
      case 'listBackups': return await listBackups(OPENID, event);
      case 'exportFamily': return await exportFamily(OPENID, event);
      case 'restoreBackup': return await restoreBackup(OPENID, event);
      default: return failure('UNKNOWN_ACTION', '不支持的家庭数据操作。');
    }
  } catch (error) {
    logger.error('familyApi failed', error);
    return failure('INTERNAL_ERROR', '服务暂时不可用，请稍后重试。');
  }
}

  return main;
}

exports.createFamilyApi = createFamilyApi;
exports.main = createFamilyApi({
  database: cloud.database(),
  getWXContext: () => cloud.getWXContext(),
  logger: console,
});
